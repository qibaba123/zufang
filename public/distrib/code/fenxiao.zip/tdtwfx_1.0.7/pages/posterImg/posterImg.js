var app = getApp();
Page({
  data: {
    
  },
  onLoad: function (e) {
    var that = this;
    that.setData({
			posterInfo: app.globalData.posterInfo
    })
		console.log(app.globalData.posterInfo);
		if (!that.data.posterInfo.posterImg){
      return;
    }
    wx.showLoading({
      title: '加载中',
      mask: true,
      time: 100000
    })
    wx.downloadFile({
			url: that.data.posterInfo.posterImg,
      success: function (res) {
        console.log(res);
        that.setData({
          tempFilePathShow:res.tempFilePath
        })
        wx.hideLoading();
      }
    })
  },
  // onShareAppMessage: function () {
  //   var title = this.data.sharedata.shareTitle;
  //   var image = this.data.tempFilePathShow;
  //   console.log(image);
  //   return {
  //     title: title,
  //     imageUrl: image,
  //     path: '/pages/index/index'
  //   }
  // },
  saveImage:function(){
    var that = this;
		var imgpath = this.data.posterInfo.posterImg;
    var tempFilePathShow = this.data.tempFilePathShow;
    if (imgpath.length<=0){
      app.errorTip(that, "海报图片不存在", 2000);
      return;
    }
    wx.showLoading({
      title: '正在保存',
      mask: true,
      time: 100000
    })
    wx.saveImageToPhotosAlbum({
      filePath: tempFilePathShow,
      success(res) {
        console.log(res);
        app.errorTip(that, "图片保存成功", 2000);
      },
      fail(f) {
        app.errorTip(that, "图片保存失败", 2000);
      },
      complete() {
        wx.hideLoading();
      }
    })
  },
	requestPoster: function () {
		var that = this;
		var memberInfo = app.globalData.memberInfo;
		var data = {};
		data.map = 'applet_three_reset_spread';
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					wx.downloadFile({
						url: res.data.data.spreadImage,
						success: function (res) {
							console.log(res);
							that.setData({
								tempFilePathShow: res.tempFilePath
							})
							app.errorTip(that, "销毁重建成功", 2000);
						}
					})
					console.log(that.data.posterInfo);
					
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
})