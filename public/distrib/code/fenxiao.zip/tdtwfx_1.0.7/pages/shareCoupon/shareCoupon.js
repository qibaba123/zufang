//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
  onLoad:function(e){
    var that = this;
    that.setData({
      cid: e.id,
      namelogo: app.globalData.namelogo
    })
    console.log(that.data.cid);
  },
  getCoupon: function (e) {
    var that = this;
    var id = e.target.dataset.id;
    console.log(id);
    wx.showLoading({
      title: '领取中',
      mask: true
    })
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_coupon_receive',
        cid: id
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          var couponInfo = {
            couponDetail: res.data.data.coupon,
            receiveList: res.data.data.receiveList
          };
          wx.setStorage({
            key: "couponInfo",
            data: couponInfo,
            success: function () {
              wx.redirectTo({
                url: '/pages/useCoupon/useCoupon'
              })
            }
          })

        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideLoading();
      }
    })
  },
  onShareAppMessage: function () {
    var that = this;
    var title = app.globalData.namelogo.name;
    var id = that.data.cid;
    console.log(title);
    return {
      title: title,
      path: '/pages/shareCoupon/shareCoupon?id=' + id
    }
  },
})
