var app = getApp();
Page({
  data: {
    
  },
  onLoad: function (e) {
    var that = this;
    
    var mid = decodeURIComponent(e.scene)
    that.setData({
      mid: mid
    })
    console.log(that.data.mid);
    
    if (!app.globalData.plumSession){
      that.getUserInfo(mid);
    }else{
      that.requestdistributionInfo(mid);
    }
  },
  onShow:function(){
    var that = this;
    var mid = that.data.mid;
    if (!app.globalData.plumSession) {
      console.log("暂未获取到session");
      that.getUserInfo(mid);
    } else {
      console.log("已获取到session");
      if (mid){
        that.requestdistributionInfo(mid);
      }
    }
    
  },
  getUserInfo:function(mid){
    var that = this;
    wx.login({
      success: function (res) {
        var code = res.code;
        console.log(code);
        if (res.code) {
          wx.getUserInfo({
            success: function (res2) {
              var encryptedData = encodeURI(res2.encryptedData);
              var iv = encodeURI(res2.iv);
              var data = {
                map: 'applet_three_member_info',
                suid: app.globalData.suid,
                code: code,
                encryptedData: encryptedData,
                iv: iv
              };
              console.log(data);
              console.log('code=' + code + '&encryptedData=' + encryptedData + '&iv=' + iv);
              wx.request({
                url: app.globalData.requestUrl,
                data: data,
                success: function (res) {
                  if (res.data.ec == 200) {
                    console.log("获取用户信息成功");
                    console.log(res.data.data);
                    app.globalData.requestUrl = app.globalData.requestUrl + '&plum_session_applet=' + res.data.data.plum_session_applet;
                    wx.setStorage({
                      key: "plumSession",
                      data: res.data.data.plum_session_applet,
                      success: function () {
                        app.globalData.plumSession = res.data.data.plum_session_applet;
                      }
                    })

                    if (app.globalData.userInfo) {
                      typeof cb == "function" && cb(app.globalData.userInfo)
                    } else {
                      app.globalData.userInfo = res.data.data
                      typeof cb == "function" && cb(app.globalData.userInfo)
                    }
                    that.requestdistributionInfo(mid);
                  } else {
                    console.log(res.data);
                    console.log("获取用户信息失败");
                    wx.showToast({
                      title: '获取用户信息失败',
                      icon: 'success',
                      image: '/images/error_tip.png',
                      duration: 3000
                    })
                  }
                },
                complete: function () {
                  console.log("执行完成");
                }
              });
            },
            fail: function () {
              wx.showModal({
                title: '警告',
                content: '您拒绝了授权，将无法正常使用该小程序的功能体验。请允许授权哦~。',
                showCancel: false,
                confirmText: '去授权',
                success: function (res) {
                  if (res.confirm) {
                    app.openSetting();
                  }
                }
              })
            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  },
	requestdistributionInfo: function (mid) {
		var that = this;
		var data = {};
		data.map = 'applet_three_set_level';
		data.mid = mid;
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            distributionInfo: res.data.data
          })
          console.log(that.data.distributionInfo);
          // app.errorTip(that, res.data.data.tip, 2000);
        } else {
          // app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
	},
	backSy:function(){
		wx.reLaunch({
			url: '/pages/index/index'
		})
	}
})