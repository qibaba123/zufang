var app = getApp()
Page({
  data: {
    showType: 'changeTel',
    isShowModal: false,
    userInfo: {}
  },
  onLoad: function () {
    var that = this
    that.setData({
      userInfo: app.globalData.userInfo
    })
    app.setVersion(that);
  },
  myAddress: function () {
    if (!app.globalData.plumSession) {
      wx.showModal({
        title: '操作提示',
        content: '允许授权后才可进行其它操作哦~重新授权请查看-我-帮助中心',
        confirmText: '确定',
        confirmColor: '#1AAD16',
        success: function (res) {
          if (res.confirm) {
            // app.wechatSq();
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      console.log("暂未获取到信息");
    } else {
      wx.navigateTo({
        url: '../addressManage/addressManage'
      })
    }
    
  },
  openHelpCenter: function () {
    wx.navigateTo({
      url: '../helpCenter/helpCenter'
    })
  },
  openMyOrder: function () {
    wx.navigateTo({
      url: '../myorder/myorder'
    })
  },
  contactKefu: function () {
    console.log('检测是否已登录');
    var that = this;
    wx.showModal({
      title: '',
      content: '联系客服请先登录天店通账号哦~',
      cancelText: '我知道了',
      confirmText: '立即登录',
      confirmColor: '#48C23D',
      success: function (res) {
        if (res.confirm) {
          that.setData({
            isShowModal: true
          })
        }
      }
    })
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  showOpera: function (e) {
    var type = e.target.dataset.type;
    var showtype = "";
    var that = this;
    if (type == 'confirmTel') {
      var isReg = true;
      if (isReg) {
        showtype = 'logPart';
      } else {
        showtype = 'regPart';
      }
      console.log("检测是否注册");
    } else {
      showtype = type;
    }
    that.setData({
      showType: showtype
    })
  },
  // makeCall: function () {
  //   wx.showModal({
  //     title: '',
  //     content: '联系商家客服 0371-86258375?',
  //     success: function (res) {
  //       if (res.confirm) {
  //         wx.makePhoneCall({
  //           phoneNumber: '0371-86258375',
  //           success: function () {
  //             console.log("拨打电话成功！")
  //           },
  //           fail: function () {
  //             console.log("拨打电话失败！")

  //           }
  //         })
  //       }
  //     }
  //   })
  // },
  makeCall: function () {
    app.makeCall();
  }
})