//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    type: 2,
    showLoading: true,
    noMoretip: false,
    page: 0
  },
  onShow:function(){
    app.setNavtitle('资讯');

  },
  onLoad: function () {
    var that = this;
    setTimeout(function () {
      that.requestServiceFl();
    }, 1)
  },
  requestServiceFl: function () {
    var that = this;
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_applet_information_category'
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            newsTab: res.data.data,
            curNewsId: res.data.data[0].id
          })
          var cid = that.data.curNewsId;
          that.requestServiceList(cid);
        } else {
          that.setData({
            newsTab: []
          })
          that.requestServiceList(0);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  requestServiceList: function (cid) {
    var that = this;
    var data = {};
    var page = that.data.page;
    var type = that.data.type;
    var sortType = that.data.sortType;
    data.map = 'applet_applet_information_list';
    data.categoryId = cid;
    data.page = page;
    app.setVersion(that);
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(page);
        console.log(res.data);
        if (res.data.ec == 200) {
          var allArr = [];
          var initArr = that.data.newsList ? that.data.newsList:[];
          var curArr = res.data.data.list;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data.list;
          }
          that.setData({
            newsList: allArr,
            liststyle: res.data.data.style
          })
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          console.log(that.data.newsList);
        } else {
          if (page <= 0) {
            that.setData({
              newsList: [],
              noMoretip: false,
              showLoading: false
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  newsToggle: function (e) {
    var that = this;
    var id = e.target.dataset.id;
    that.setData({
      page:0,
      curNewsId: id,
      newsList: null,
      noMoretip: false,
      showLoading: true
    })
    that.requestServiceList(id);
  },
  onPullDownRefresh: function () {
    var that = this;
    var cid = that.data.curNewsId;
    that.setData({
      page: 0,
      noMoretip: false,
      showLoading: true,
      curNewsId: cid
    });
    that.requestServiceList(cid);
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    var cid = that.data.curNewsId;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      that.requestServiceList(cid);
    }
  },
  seeDetail: function (e) {
    var id = e.currentTarget.dataset.id;
    var title = e.currentTarget.dataset.title;
    console.log(id);
    console.log(title);
    wx.navigateTo({
      url: '/pages/informationDetail/informationDetail?id=' + id + '&title=' + title
    })
  },
  makeCall: function () {
    app.makeCall();
  },
  onShareAppMessage: function () {
    return {
      title: '资讯',
      path: 'pages/information/information'
    }
  }
})
