var app = getApp()
Page({
  data: {
    isHasAddress: true,
    isShowModal:false,
    shopname: '',
    orderInfo: {},
    note: "",
    errorTip: {
      text: '',
      isShow: false
    },
    curCouponId:'',
    curPromotionId:''
  },
  onLoad: function (e) {
    var that = this;
    wx.getStorage({
      key: 'submitOrder',
      success: function (res) {
        console.log(res.data);
        that.setData({
          orderInfo: res.data,
          addressInfo: res.data.address,
          cardNum: res.data.idcard,
          sumTotal: res.data.total
        })
      }
    })
    
    wx.getStorage({
      key: 'shopInfoname',
      success: function (res) {
        that.setData({
          shopname: res.data
        })
      }
    })
    var ordersource = e.ordersource;
    that.setData({
      ordersource: ordersource
    })
    app.setVersion(that);
  },
  onShow: function () {
    var that = this;
    wx.getStorage({
      key: 'submitOrder',
      success: function (res) {
        console.log(res.data);
        that.setData({
          orderInfo: res.data,
          addressInfo: res.data.address,
          sumTotal: res.data.total
        })
      }
    })
    wx.getStorage({
      key: 'delCart',
      success: function (res) {
        that.setData({
          cartids: res.data
        })
      }
    })
  },
  switchChange: function (e) {
    console.log('switch 发生 change 事件，携带值为', e.detail.value)
  },
  addAddress: function (e) {
    // var type = e.currentTarget.dataset.type;
    wx.navigateTo({
      url: '../addAddress/addAddress?type=orderadd'
    })
  },
  chooseAddress: function (e) {
    var that = this;
    var type = e.currentTarget.dataset.type;
    var orderStatus = that.data.orderstatus;
    console.log(orderStatus);
    if (!orderStatus){}else{return;}
    console.log(type);
    wx.navigateTo({
      url: '../addressManage/addressManage?type=' + type
    })
  },
  noteChange: function (e) {
    this.setData({
      note: e.detail.value
    })
  },
  cardChange:function(e){
    this.setData({
      cardNum: e.detail.value
    })
  },
  submitOrder: function () {
    var that = this;
    var data = {};
    data.map = 'applet_order_confirm';
    data.tid = that.data.orderInfo.tid;
    data.postFee = that.data.orderInfo.postTotal;
    if (that.data.addressInfo.id) {
      data.addrid = that.data.addressInfo.id;
    } else {
      data.addrid = "";
    }
    data.note = that.data.note;
    var ordersource = that.data.ordersource;
    if (ordersource == 'cartorder') {
      data.cartids = that.data.cartids;
    }
    if (!data.addrid) {  
      app.errorTip(that, "请选择收货地址", 2000);
    }
    if (that.data.orderInfo.global > 0) {
      data.idcard = that.data.cardNum;
      if (data.idcard) {
        console.log("全球购");
      } else {
        app.errorTip(that, "身份证号不能为空", 2000);
        return false;
      }
    }
    if (that.data.chooseCoupon){
      data.yhqid = that.data.chooseCoupon.id;
    }
    if (that.data.choosePromotion) {
      data.cxid = that.data.choosePromotion.id;
    }
    console.log(data);
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 3000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(data);
          console.log(res.data.data);
          that.setData({
            orderstatus: res.data.data.status
          })
          if (res.data.data.status == 'dzf') {
            that.orderPay();
          }
          // app.errorTip(that, res.data.data.msg, 2000);
        } else {
          console.log(res.data.em);
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
    
  },
  orderPay: function (e) {
    var that = this;
    var data = {};
    data.map = 'applet_order_pay';
    data.tid = that.data.orderInfo.tid;
    wx.hideToast();
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 1000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          wx.requestPayment({
            'appId': res.data.data.appId,
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (res) {
              wx.redirectTo({
                url: '../paySuccess/paySuccess?orderid=' + data.tid
              })
            },
            'fail': function (res) {
              console.log(res);
            }
          });
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  showModal:function(e){
    var that = this;
    var type = e.currentTarget.dataset.type;
    var orderInfo = that.data.orderInfo;
    var couponLen = orderInfo.coupon.length;
    var fullActLen = orderInfo.fullAct.length;
    var orderStatus = that.data.orderstatus;
    console.log(orderStatus);
    if (!orderStatus) { } else { return; }
    if (type == 'coupon' && couponLen>0){
      that.setData({
        curChooseType:'coupon',
        isShowModal:true
      })
    }
    if (type == 'promotion' && couponLen > 0) {
      that.setData({
        curChooseType: 'promotion',
        isShowModal: true
      })
    }
  },
  hideModal:function(){
    var that = this;
    that.setData({
      isShowModal:false
    })
  },
  toggleCoupon:function(e){
    var that = this;
    var coupon = e.currentTarget.dataset.coupon;
    that.setData({
      curCouponId: coupon.id,
      curCouponInfo: coupon
    })
  },
  confirmChooseCoupon:function(){
    var that = this;
    var curTotal = that.data.orderInfo.total;
    var curCouponVal = that.data.curCouponInfo.value;
    var total = curTotal - curCouponVal;
    console.log(total);
    if (that.data.curPromotionInfo) {
      var curPromotionVal = that.data.curPromotionInfo.value;
      total = total - curPromotionVal;
    }
    if (total<=0){
      total = 0;
    }
    that.setData({
      chooseCoupon: that.data.curCouponInfo,
      sumTotal:total
    })
    that.hideModal();
  },
  togglePromotion: function (e) {
    var that = this;
    var promotion = e.currentTarget.dataset.promotion;
    that.setData({
      curPromotionId: promotion.id,
      curPromotionInfo: promotion
    })
  },
  confirmChoosePromotion: function () {
    var that = this;
    var curTotal = that.data.orderInfo.total;
    var curPromotionVal = that.data.curPromotionInfo.value;
    var total = curTotal - curPromotionVal;
    if (that.data.curCouponInfo){
      var curCouponVal = that.data.curCouponInfo.value;
      total = total - curCouponVal;
    }
    console.log(total);
    that.setData({
      choosePromotion: that.data.curPromotionInfo,
      sumTotal: total
    })
    that.hideModal();
  }
})