// pages/Generalreservationdetail/Generalreservationdetail.js
var app = getApp()
var WxParse = require('../../wxParse/wxParse.js');

Page({

  data: {
    isShowModal: false,
    chooseGuige: {},
    buyNumber: 1,
    modalOperaType: "buy",

  },
  onLoad: function (e) {
    var that = this;
    that.setData({
      gid: e.id
    })
    wx.showLoading({
      title: '加载中...',
    })
    // setTimeout(function () {
    //   that.loadData();
    // }, "1000");
    that.loadData();
  },
  onShow:function(){
    var that = this;
    that.setData({
      customerService: app.globalData.customerService
    })
  },
  loadData: function () {
    var that = this;

    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_appointment_good_detail"),
      data: {
        gid: that.data.gid,
        map:'applet_appointment_good_detail'
      },
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          that.setData({
            info: res.data.data,
            goodDetail: res.data.data
          })
          WxParse.wxParse('article', 'html', res.data.data.detail, that, 5);

        } else {

        }
      },
      fail: function () {
        console.log("fail")
      },
      complete: function () {
        wx.hideLoading()
      }
    })
  },
  //显示购买弹层
  showDetailView: function () {
    var that = this;

    if(!that.data.info){
      return;
    }
    that.setData({
      isShowModal: true
    })
  },
  //隐藏
  hideModal: function () {
    var that = this;
    that.setData({
      isShowModal: false
    })
  },

  reservationDetail: function () {
    var that = this;

    wx.navigateTo({
      url: '../Generalreservationdetailfillorder/Generalreservationdetailfillorder?id=' + that.data.gid,
    })
  },
  chooseGuige: function (e) {
    var that = this;
    var id = e.target.dataset.id;
    var price = e.target.dataset.price;
    var stock = e.target.dataset.stock;
    var name = e.target.dataset.name;
    that.setData({
      chooseGuige: {
        id: id,
        price: price,
        stock: stock,
        name: name
      }
    })
  },
  //数量
  changeNum: function (e) {
    var that = this;
    var type = e.currentTarget.dataset.type;
    var buyNum = parseInt(that.data.buyNumber);
    if (type == 'add') {
      buyNum++;
    } else {
      if (buyNum > 1) {
        buyNum--;
      } else {
        buyNum = 1;
      }
    }
    that.setData({
      buyNumber: buyNum
    })
  },
  //下一步
  nextStep: function () {
    var that = this;
    var gfid = that.data.chooseGuige.id;


    if (that.data.goodDetail.format.length != 0 && !that.data.chooseGuige.id) {

     
      wx.showToast({
        title: '请选择项目',
        image: "/images/hud_info.png",
        // icon: "loading",
        duration: 1000,
        mask: true
      })
      return;
    }

    if (that.data.buyNumber == 0) {
     
      wx.showToast({
        title: '请选择购买数量',
        image: "/images/hud_info.png",
        // icon: "loading",
        duration: 1000,
        mask: true
      })
      return;
    }

    wx.navigateTo({
      url: '../Generalreservationdetailfillorder/Generalreservationdetailfillorder?id=' + that.data.gid + "&num=" + that.data.buyNumber + "&gfid=" + that.data.chooseGuige.id,
    })
    // var isFormat = that.data.goodDetail.format.length > 0;
    // var orderArr = [];
    // var orderObj = {};
    // orderObj.gid = that.data.goodDetail.id;
    // orderObj.gfid = that.data.chooseGuige.id;;
    // orderObj.num = that.data.buyNumber;

    // wx.showLoading({
    //   title: '加载中...',
    // })
    // wx.request({
    //   url: app.getRequestUrl("/applet.php?map=applet_appointment_create_trade"),
    //   data: {
    //     buys: [{ "gid": that.data.gid, "num": that.data.buyNumber, gfid: that.data.chooseGuige.id }],
    //     plum_session_applet: app.globalData.plumSession
    //   },
    //   success: function (res) {
    //     console.log(res)
    //     if (res.data.ec == 200) {
    //       that.setData({
    //         info: res.data.data
    //       })

    //     } else {

    //     }
    //   },
    //   fail: function () {
    //     console.log("fail")
    //   },
    //   complete: function () {
    //     wx.hideLoading()
    //   }
    // })
  },



})