//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    showLoading: true,
    noMoretip: false,
    page: 0
  },
  onLoad:function(){
    var that = this;
    that.requestCouponlist();
  },
  // 优惠券
  toCouponlist: function () {
    wx.navigateTo({
      url: '/pages/couponList/couponList'
    })
  },
  toShareCoupon: function (e) {
    var id = e.target.dataset.id;
    if(!id){
      return;
    }
    wx.navigateTo({
      url: '/pages/shareCoupon/shareCoupon?id='+id
    })
  },
  toIndexuse: function () {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  toAllgoods: function (e) {
    var id = e.currentTarget.dataset.id;
    var type = e.currentTarget.dataset.type;
    wx.navigateTo({
      url: '/pages/searchList/searchList?id='+id+'&type='+type
    })
  },
  requestCouponlist: function (type) {
    var that = this;
    var data = {};
    var page = that.data.page;
    data.map = 'applet_my_coupon';
    data.page = page;
    data.type = type;
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(page);
        console.log(res.data);
        if (res.data.ec == 200) {
          var allArr = [];
          var initArr = that.data.couponList ? that.data.couponList : [];
          var curArr = res.data.data;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data;
          }
          that.setData({
            couponList: allArr
          })
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          console.log(that.data.couponList);
        } else {
          if (page <= 0) {
            that.setData({
              couponList: [],
              noMoretip: false,
              showLoading: false
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    var type = that.data.type;
    that.requestCouponlist(type);
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    var sortType = that.data.curSort;
    var curLng = that.data.curLng;
    var curLat = that.data.curLat;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      var type = that.data.type;
      that.requestCouponlist(type);
    }
  },
})
