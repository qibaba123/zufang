//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    isDisable:true
  },
  onLoad:function(){
    var that = this;
    that.setData({
      namelogo:app.globalData.namelogo
    })
    console.log(app.globalData.plumSession);
    if (!app.globalData.plumSession){
      app.wechatSq();
    }
  },
  onShow:function(){
    var that = this;
    app.setNavtitle('支付');
    that.setData({
      isFocus:true
    })
  },
  moneyChange:function(e){
    var that = this;
    var curVal = e.detail.value;
    var disable = true;
    if (curVal>0){
      disable = false;
    }else{
      disable = true;
    }
    that.setData({
      moneyVal: curVal,
      isDisable: disable
    })
  },
  payCodePage:function(){
    wx.navigateTo({
      url: '/pages/paycode/paycode'
    })
  },
  orderPay: function (e) {
    var that = this;
    var data = {};
    data.map = 'applet_cash_pay';
    data.money = that.data.moneyVal;
    if (!data.money){
      return;
    }
    console.log(data);
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          wx.requestPayment({
            'appId': res.data.data.appId,
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (res) {
              console.log(res);
              console.log("支付成功");
              that.setData({
                moneyVal: "",
                isDisable: true
              })
              wx.navigateTo({
                url: '/pages/successtip/successtip?money=' + data.money
              })
            },
            'fail': function (res) {
              wx.showModal({
                title: '',
                content: '支付失败',
                showCancel: false
              });
            }
          });
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.em,
            showCancel: false
          });
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
})
