var app = getApp()
Page({
  data: {
		isUnfold:true,
		money:'',
		name:'',
		phone:'',
		account:''
  },
  onLoad: function (options) {
		var that = this;
		that.requestmemberInfo();
  },
  
  onShow: function () {
		
  },
	requestmemberInfo: function () {
		var that = this;
		var data = {};
		data.map = 'applet_three_member_info';
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					var memberInfo = res.data.data;
					app.globalData.memberInfo = memberInfo;
					that.setData({
						memberInfo: app.globalData.memberInfo
					})
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
	clickUnfold: function () { // 展开折叠我的会员
		var that = this;
		that.setData({
			isUnfold: !that.data.isUnfold
		})
	},
	towithdrawRecord: function (e) {// 提现记录
		wx.navigateTo({
			url: '/pages/withdrawRecord/withdrawRecord'
		})
	},
	moneyChange:function(e){
		var that = this;
		that.setData({
			money:e.detail.value
		})
	},
	nameChange: function (e) {
		var that = this;
		that.setData({
			name: e.detail.value
		})
	},
	phoneChange: function (e) {
		var that = this;
		that.setData({
			phone: e.detail.value
		})
	},
	accountChange: function (e) {
		var that = this;
		that.setData({
			account: e.detail.value
		})
	},
	confirmSubmit:function(){
		var that = this;
		var data={
			map : 'applet_three_apply_tx',
			money: that.data.money,
			name: that.data.name,
			phone: that.data.phone,
			account: that.data.account
		}
		if (data.money == "" || data.money<=0){
			app.errorTip(that, '提现金额必须为整数', 2000);
			return;
		}
		if (data.money > that.data.memberInfo.deduct_ktx){
			app.errorTip(that, '提现金额大于可提现金额', 2000);
			return;
		}
		if (data.name == "") {
			app.errorTip(that, '姓名不能为空', 2000);
			return;
		}
		if (data.phone == "") {
			app.errorTip(that, '手机号不能为空', 2000);
			return;
		}
		console.log(data);
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					app.errorTip(that, res.data.data.msg, 2000);
					that.requestmemberInfo();
					that.setData({
						money: '',
						name: '',
						phone: '',
						account: ''
					})
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
  onShareAppMessage: function () {
  
  }
})