// pages/Generalreservationlist/Generalreservationlist.js
var app = getApp()
Page({

  data: {
    currentIndex: 0,
    status: "all",
    page: 0,
    // datasource: [],
    moreDataTip: "正在加载中"
    // allsource: [],
    // allpage: 0,
    // nopaysource: [],
    // nopaypage: 0,
    // hadpaysource: [],
    // hadpaypage: 0,
    // finishsource: [],
    // finishpage: 0
  },
  onLoad: function () {
    var that = this;
    that.loadData();
  },
  itemClick: function (e) {
    var id = e.currentTarget.dataset.id;
    var that = this;
    var statu = "";
    if (id == 0) {
      statu = "all"
    } else if (id == 1) {
      statu = "nopay"
    } else if (id == 2) {
      statu = "hadpay"
    } else if (id == 3) {
      statu = "finish"
    }

    that.setData({
      currentIndex: id,
      status: statu,
      datasource: []
    })
    that.loadData();

  },
  onPullDownRefresh: function () {
    var that = this;
    that.loadData();

  },
  onReachBottom: function () {
    var that = this;
    that.loadMoreData();
  },
  loadData: function () {
    var that = this;
    that.setData({
      datasource: null,

      moreDataTip: "正在加载中",
    })
    if (!that.datasource) {
      wx.showLoading({
        title: '加载中',
      })
    }
    console.log(that.data.status)
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_appointment_order_list"),
      data: {
        map:'applet_appointment_order_list',
        status: that.data.status,
        page: 0,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          that.setData({
            datasource: res.data.data,
            page: 0
          })
        } else {
          that.setData({
            moreDataTip: "没有更多数据了",
            datasource: []
          })
        }
      },
      fail: function () {
      },
      complete: function () {
        wx.stopPullDownRefresh();
wx.hideLoading()
      }
    })
  },
  loadMoreData: function () {
    var that = this;
    var currenpage = that.data.page + 1

    console.log(that.data.status)
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_appointment_order_list"),
      data: {
        map: 'applet_appointment_order_list',

        status: that.data.status,
        page: currenpage,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          var caurunData = that.data.datasource;

          caurunData = caurunData.concat(res.data.data)
          console.log(caurunData.length)
          that.setData({
            datasource: caurunData,
            page: currenpage
          })
        } else {
          that.setData({
            moreDataTip: "没有更多数据了"
          })
        }
      },
      fail: function () {

      }
    })
  },
  getcurrentPage: function () {
    var that = this;

    var currentPage = 0;
    switch (that.data.currentIndex) {
      case 0:
        currentPage = that.data.allpage

        break;
      case 1:
        currentPage = that.data.nopaypage
        break;
      case 2:
        currentPage = that.data.hadpaypage

        break;
      case 3:
        currentPage = that.data.finishpage

        break;

    }

    return currentPage;
  },
  setcurrentPage: function () {
    var that = this;
    var addpage = that.getcurrentPage() + 1;

    switch (that.data.currentIndex) {
      case 0:
        that.setData({
          allpage: addpage
        })
        break;
      case 1:
        that.setData({
          nopaypage: addpage
        })
        break;
      case 2:
        that.setData({
          hadpaypage: addpage
        })
        break;
      case 3:
        that.setData({
          finishpage: addpage
        })
        break;

    }

  },
  //取消订单
  cancelOrder: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var id = e.currentTarget.dataset.tid;
    // console.log(index)
    // console.log(tid);
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_cancel_order"),
      data: {
        map:'applet_cancel_order',
        tid: id,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {

        console.log(res)
        if (res.data.ec == 200) {
          that.loadData()
          that.showTost(res.data.data.msg)
        } else {
          that.showTost(res.data.em)

          // wx.showToast({
          //   title: res.data.em,
          // })
        }
      },
      fail: function () {

      }
    })
  },
  //付款点击
  paymentClick: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    var id = e.currentTarget.dataset.tid;
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_order_pay"),
      data: {
        map:'applet_order_pay',
        tid: id,
        money: that.data.datasource[index].total,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {
        console.log(res.data)
        if (res.data.ec == 200) {
          wx.requestPayment({
            'appId': res.data.data.appId,
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (res) {
              console.log(res);
              console.log("支付成功");
              that.showTost("支付成功")
              that.loadData();
              // that.setData({
              //   moneyVal: "",
              //   isDisable: true
              // })
              // wx.navigateTo({
              //   url: '/pages/successtip/successtip?money=' + data.money
              // })
            },
            'fail': function (res) {
              that.showTost("支付失败")
              // wx.showModal({
              //   title: '',
              //   content: '支付失败',
              //   showCancel: false
              // });
              // wx.navigateTo({
              //   url: '/pages/successtip/successtip?money=' + data.money
              // })
            }
          });
        } else {
          wx.hideLoading()
          that.showTost(res.data.em);


        }
      },
      fail: function () {
        wx.hideLoading()

      }
    })
  },
  showTost: function (toast) {
    wx.showToast({
      title: toast,
      image: "/images/hud_info.png",
      // icon: "loading",
      duration: 1000,
      mask: true
    })
  }

  // setdatasource:function(source){
  //   var that = this;
  //   switch (that.data.currentIndex) {
  //     case 0:
  //       var currentsource = that.data.allsource
  //       currentsource.concat(source)
  //       that.setData({
  //         allsource: currentsource
  //       })
  //       break;
  //     case 1:
  //       var currentsource = that.data.nopaysource
  //       currentsource.concat(source)
  //       that.setData({
  //         nopaysource: currentsource
  //       })
  //       break;
  //     case 2:
  //       var currentsource = that.data.hadpaysource
  //       currentsource.concat(source)
  //       that.setData({
  //         hadpaysource: currentsource
  //       })
  //       break;
  //     case 3:
  //       var currentsource = that.data.finishsource
  //       currentsource.concat(source)
  //       that.setData({
  //         finishsource: currentsource
  //       })
  //       break;

  //   }
  // }
})