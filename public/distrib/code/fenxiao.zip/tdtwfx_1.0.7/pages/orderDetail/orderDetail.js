var app = getApp()
Page({
  data: {
    isShowModal: false,
    modalType: '',
    isHasAddress: false,
    second: 10,
    remainTime: '',
    userInfo: {},
    orderId: '',
    errorTip: {
      text: '',
      isShow: false
    },
    orderDetail: {},
    tkOrderid: "",
    tkMoney: "",
    tkReason: "",
    tkContact: ""

  },
  onLoad: function (e) {
    var that = this;
    // countdown(that);
    that.setData({
      orderId: e.orderid,
      customerService: app.globalData.customerService
    })
    wx.getStorage({
      key: 'shopInfoname',
      success: function (res) {
        that.setData({
          shopname: res.data
        })
      }
    })
    app.setVersion(that);
  },
  onShow: function () {
    var that = this;
    var orderid = that.data.orderId;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_detail',
        // suid: app.globalData.suid,
        tid: orderid
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          that.setData({
            orderDetail: res.data.data
          })
          // wx.showToast({
          //   title: res.data.data.msg,
          //   icon: 'success',
          //   duration: 2000,
          //   success: function () {
          //     wx.navigateBack({
          //       delta: 1
          //     })
          //   }
          // })
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.em,
            showCancel: false
          });
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  makeCall: function () {
    wx.showModal({
      title: '提示',
      content: '确定商家电话 0371-86258375?',
      success: function (res) {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: '0371-86258375',
            success: function () {
              console.log("拨打电话成功！")
            },
            fail: function () {
              console.log("拨打电话失败！")

            }
          })
        }
      }
    })
  },
  openHelpCenter: function () {
    wx.navigateTo({
      url: '../helpCenter/helpCenter'
    })
  },
  cancelTk: function (e) {
    var that = this;
    var tid = e.target.dataset.tid;
    wx.showModal({
      title: '',
      cancelText: '再考虑下',
      confirmText: '确认',
      content: '确认撤销维权吗？',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_refund_cancel',
              // suid: app.globalData.suid,
              tid: tid
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onShow();
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  orderPay: function (e) {
    var that = this;
    var data = {};
    data.map = 'applet_order_pay';
    // data.suid = app.globalData.suid;
    data.tid = that.data.orderDetail.tid;
    data.money = that.data.orderDetail.total;
    
    wx.login({
      success: function (res) {
        if (res.code) {
          data.code = res.code;
          console.log(data);
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: data,
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                wx.requestPayment({
                  'appId': res.data.data.appId,
                  'timeStamp': res.data.data.timeStamp,
                  'nonceStr': res.data.data.nonceStr,
                  'package': res.data.data.package,
                  'signType': 'MD5',
                  'paySign': res.data.data.paySign,
                  'success': function (res) {
                    wx.navigateTo({
                      url: '../paySuccess/paySuccess?orderid=' + data.tid
                    })
                  },
                  'fail': function (res) {
                    wx.showModal({
                      title: '',
                      content: '支付失败',
                      showCancel: false
                    });
                  }
                });
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  },
  remindSend: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_remind',
        // suid: app.globalData.suid,
        tid: orderId
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          app.errorTip(that, res.data.data.msg, 2000);
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  extendReceiving: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    wx.showModal({
      title: '确认延长收货时间？',
      cancelText: '取消',
      confirmText: '确认',
      content: '每个订单只能延长收货一次哦~',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_extended_delivery',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  confirmReceiving: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    wx.showModal({
      title: '',
      cancelText: '还没收到',
      confirmText: '确认收货',
      content: '确认收到货物了吗？',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_confirm_accept',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onPullDownRefresh();
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  seeWuliu: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_fetch_track',
        // suid: app.globalData.suid,
        tid: orderId
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data.track.Traces);
          that.setData({
            modalType: 'wuliu',
            isShowModal: true,
            logisticsInfo: res.data.data.track.Traces
          })
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  applyTuikuan: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    var total = that.data.orderDetail.total;
    that.setData({
      modalType: 'tuikuan',
      tkMoney: total,
      tkReason: "",
      tkContact: "",
      isShowModal: true,
      tkOrderid: orderId
    })
  },
  seeWeiquan:function(){
    var that = this;
    var orderId = that.data.orderDetail.tid;
    wx.navigateTo({
      url: '../feedbackRecord/feedbackRecord?orderid=' + orderId
    })
  },
  tkMoneyChange: function (e) {
    this.setData({
      tkMoney: e.detail.value
    })
  },
  tkReasonChange: function (e) {
    this.setData({
      tkReason: e.detail.value
    })
  },
  tkContactChange: function (e) {
    this.setData({
      tkContact: e.detail.value
    })
  },
  submitTkapply: function () {
    var that = this;
    var data = {};
    data.map = 'applet_order_refund';
    // data.suid = app.globalData.suid,
    data.tid = that.data.tkOrderid;
    data.money = that.data.tkMoney;
    data.reason = that.data.tkReason;
    data.contact = that.data.tkContact;

    if (data.money == "") {
      app.errorTip(that, "请输入退款金额", 2000);
    } else {
      if (data.reason == "") {
        app.errorTip(that, "请输入退款原因", 2000);
      } else {
        if (data.contact == "") {
          app.errorTip(that, "请输入您的联系方式", 2000);
        } else {
          console.log(data);
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: data,
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onShow();
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              that.setData({
                isShowModal: false
              })
              wx.hideToast();
            }
          });
        }
      }
    }
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  delOrder: function (e) {
    var that = this;
    var orderId = that.data.orderDetail.tid;
    wx.showModal({
      title: '删除提示',
      cancelText: '取消',
      confirmText: '确认',
      content: '确认删除该订单吗',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_delete',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                wx.navigateBack({
                  delta: 1
                })
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  goodDetail: function (e) {
    var that = this;
    var goodId = e.currentTarget.dataset.gid;
    var status = that.data.orderDetail.status;
    wx.navigateTo({
      url: '../goodDetail/goodDetail?goodid=' + goodId
    })
  }
})

/* 秒级倒计时 */
function countdown(that) {
  var second = that.data.second;
  var remainMinute = parseInt(second / 60);
  var remainSecond = second % 60;
  remainSecond = remainSecond < 10 ? ('0' + remainSecond) : remainSecond;
  that.setData({
    remainTime: remainMinute + '分' + remainSecond + '秒'
  });
  if (second == 0) {
    that.setData({
      second: 0
    });
    return;
  }
  var timer = setTimeout(function () {
    var second = that.data.second;
    var remainMinute = parseInt(second / 60);
    var remainSecond = second % 60;
    remainSecond = remainSecond < 10 ? ('0' + remainSecond) : remainSecond;
    that.setData({
      second: second - 1,
      remainTime: remainMinute + '分' + remainSecond + '秒'
    });
    countdown(that);
  }
    , 1000)
}
