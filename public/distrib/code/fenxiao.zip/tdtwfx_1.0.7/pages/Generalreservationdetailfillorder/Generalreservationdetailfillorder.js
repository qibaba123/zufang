// pages/Generalreservationfillorder/Generalreservationdetailfillorder.js
var app = getApp()
Page({
  data: {
    date: "选择日期",
    time: "选择时间",
    address: "点击选择所在区域",
    buybuttonText: '购买',
    editDisable: false,
    // startTime: '',
    startDate: '',
    note:''
    // currentDate:new date()
  },
  onLoad: function (e) {
    console.log(e.id);
    console.log(e.num);
    console.log(e.gfid);

    var that = this;
    that.setData({
      gid: e.id,
      num: e.num,
      gfid: e.gfid,
      // currentDate: new date()
    })

    var date = new Date();
    var year = date.getFullYear()
    var month = date.getMonth() + 1
    var day = date.getDate()

    var hour = date.getHours()
    var minute = date.getMinutes()
    var second = date.getSeconds()

    var subDate = year.toString() + "-" + month.toString() + "-" + day.toString()
    var subTime = hour.toString() + ":" + minute.toString()
    // console.log(year.toString() + "-" + month.toString() + "-" + day.toString())
    //   console.log(hour.toString() + ":" + minute.toString())
    that.setData({
      startDate: subDate,
      // startTime: subTime
    })
    console.log(that.data.startDate)

    if (!app.globalData.plumSession) {
      app.wechatSq();
      setTimeout(function () {
        that.loadData();

      }, 3000)
    } else {
      that.loadData();
    }
  },

  loadData: function () {
    var that = this;
    wx.showLoading({
      title: '加载中...',
    })
    wx.request({
      url: app.globalData.requestUrl,
      // url: app.getRequestUrl("/applet.php?map=applet_appointment_create_trade"),
      data: {
        map: 'applet_appointment_create_trade',
        buys: [{ "gid": that.data.gid, "num": that.data.num, "gfid": that.data.gfid }],
        // gid: that.data.gid,
        // num: 1,
        plum_session_applet: app.globalData.plumSession
      },
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          that.setData({
            info: res.data.data
          })

        } else {

        }
      },
      fail: function () {
        console.log("fail")
      },
      complete: function () {
        wx.hideLoading()
      }
    })
  },
  //日期选择
  bindDateChange: function (e) {
    var that = this;

    // console.log('picker发送选择改变，携带值为', e.detail.value)
    that.setData({
      date: e.detail.value
    })
  },
  //时间选择
  bindTimeChange: function (e) {
    var that = this;

    // console.log('picker发送选择改变，携带值为', e.detail.value)
    that.setData({
      time: e.detail.value
    })
  },
  //选择地区
  chooseArea: function () {
    var that = this;
    if (that.data.editDisable == true) {
      return;
    }
    wx.chooseLocation({
      success: function (res) {
        console.log(res)
        that.setData({
          address: res.name
        })
      },
    })
  },
  //姓名输入
  nameChanged: function (e) {
    var that = this;
    that.setData({
      username: e.detail.value
    })
  },
  //电话输入
  phoneChanged: function (e) {
    console.log(e.detail.value)
    var that = this;
    that.setData({
      userphone: e.detail.value
    })
  },
  //地址输入
  addressChanged: function (e) {
    var that = this;
    that.setData({
      detailAddress: e.detail.value
    })
  },
  //备注输入
  noteChanged: function (e) {
    var that = this;
    that.setData({
      note: e.detail.value
    })
  },
  //购买按钮点击
  buyClick: function () {
    var that = this;

    if (that.data.buybuttonText != '购买') {
      that.payment();
      return;
    }

    console.log(that.data)
    if (!that.data.username || that.data.username.length == 0) {
      that.showTost("请填写姓名");
      return;
    } else if (!that.data.userphone || that.data.userphone.length < 11 || that.data.userphone.length > 12) {
      that.showTost("请填写电话");
      return;
    } else if (that.data.time == "选择时间" || that.data.time.length == 0 || that.data.date == "选择日期" || that.data.date.length == 0) {
      that.showTost("请选择时间");
      return;
    } else if (that.data.address == "点击选择所在区域" || that.data.address.length == 0 || !that.data.detailAddress || that.data.detailAddress.length == 0) {
      that.showTost("请输入地址");
      return;
    }



    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_appointment_create_order"),
      data: {
        map: 'applet_appointment_create_order',
        tid: that.data.info.trade.tid,
        note: that.data.note,
        name: that.data.username,
        phone: that.data.userphone,
        address: that.data.address + that.data.detailAddress,
        time: that.data.date + " " + that.data.time,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          that.setData({
            editDisable: true,
            buybuttonText: "支付"
          })
          that.payment();
        } else {
          wx.hideLoading()
          that.showTost(res.data.em);
        }
      },
      fail: function () {
        console.log("fail")
        wx.hideLoading()

      },
      complete: function () {
      }
    })

  },
  //支付接口
  payment: function () {
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: app.globalData.requestUrl,

      // url: app.getRequestUrl("/applet.php?map=applet_order_pay"),
      data: {
        map: 'applet_order_pay',
        tid: that.data.info.trade.tid,
        money: that.data.info.trade.totalFee,
        plum_session_applet: app.globalData.plumSession

      },
      success: function (res) {
        console.log(res.data)
        if (res.data.ec == 200) {
          wx.hideLoading();

          wx.requestPayment({
            'appId': res.data.data.appId,
            'timeStamp': res.data.data.timeStamp,
            'nonceStr': res.data.data.nonceStr,
            'package': res.data.data.package,
            'signType': 'MD5',
            'paySign': res.data.data.paySign,
            'success': function (res) {
              console.log(res);
              console.log("支付成功");
              that.setData({
                moneyVal: "",
                editDisable: true
              })
              // that.showTost("支付成功");
              // setTimeout(function () {
                wx.redirectTo({
                  url: '/pages/Generalreservationlist/Generalreservationlist',
                })
              // }, 2000)
              // wx.navigateTo({
              //   url: '/pages/successtip/successtip?money=' + data.money
              // })
            },
            'fail': function (res) {
              // wx.showModal({
              //   title: '',
              //   content: '支付失败',
              //   editDisable: false
              // });
              wx.hideLoading();
              that.showTost("支付失败");

              // wx.navigateTo({
              //   url: '/pages/successtip/successtip?money=' + data.money
              // })
            }
          });
        } else {
          wx.hideLoading()
          that.showTost(res.data.em);


        }
      },
      fail: function () {
        wx.hideLoading()

      }
    })
  },

  showTost: function (toast) {
    wx.showToast({
      title: toast,
      image: "/images/hud_info.png",
      // icon: "loading",
      duration: 1000,
      mask: true
    })
  }

})