//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    curGoodFl: 1,
    goodsFlList: []
  },
  onShow: function () {
    app.setNavtitle('分类');

    var that = this;
    var that = this;
    if (!app.globalData.plumSession) {
      wx.reLaunch({
        url: '/pages/index/index'
      })
    }
    that.setBootomWrapH();
    that.requestGoodFl();
  },
  requestGoodFl: function () {
    console.log("请求接口");
    var that = this;
    var data = {};
    data.map = 'applet_goods_category_list';
    wx.showLoading({
      title: '加载中'
    })
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data.data);
        if (res.data.ec == 200) {
          that.setData({
            goodsFlList: res.data.data,
            curGoodFl: res.data.data[0].id
          })
        } else {
          console.log(res.data)
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  searchPage: function () {
    wx.navigateTo({
      url: '../searchList/searchList'
    })
  },
  onPullDownRefresh:function(){
    var that = this;
    that.requestGoodFl();
  },
  flGoods: function (e) {
    var oneid = e.currentTarget.dataset.oneid;
    var secondid = e.currentTarget.dataset.secondid;
    var title = e.currentTarget.dataset.title;
    console.log(oneid);
    console.log(secondid);
    wx.navigateTo({
      url: '/pages/allgoods/allgoods?oneid=' + oneid + '&secondid=' + secondid + '&title=' + title
    })
  },
  // 切换一级分类
  toggleGoodfl: function (e) {
    var that = this;
    var id = e.target.dataset.id;
    var setid = e.target.dataset.setid;
    that.setData({
      curGoodFl: id,
      goodScrollToView: setid
    })
    var query = wx.createSelectorQuery();
    query.select('#leftfl'+id).boundingClientRect(function (rect) {
      console.log(rect.top);
      that.setData({
        leftScrollViewTop: rect.top - 200
      })
    }).exec()
  },
  // 设置点餐区域高度
  setBootomWrapH: function () {
    var that = this;
    var query = wx.createSelectorQuery();
    wx.getSystemInfo({
      success: function (res) {
        query.select('#searchWrap').boundingClientRect(function (rect) {
          var bootomWrapH = res.windowHeight - rect.height;
          that.setData({
            topPartH: rect.height,
            bootomWrapH: bootomWrapH
          })
        }).exec()
        query.select('#bottomOpera').boundingClientRect(function (rect) {
          that.setData({
            bootomOperaH: rect.height
          })
        }).exec()
      }
    })
  },
  // 设置当前正在显示区域的菜品ID
  getMealOffsetY: function () {
    var that = this;
    var topPartH = that.data.topPartH;
    var query = wx.createSelectorQuery();
    query.selectAll('.good-list-item').fields({
      dataset: true,
      size: true,
      rect: true
    }, function (res) {
      var mealInfo = res;
      var curFocusId = that.getMwealListShowheight(mealInfo);
      that.setData({
        curMealFl: curFocusId
      })
    }).exec()
  },
  // 监控菜品页面滚动
  mealScroll: function (e) {
    var scrollViewTop = e.detail.scrollTop;
    this.getMealOffsetY();
  },
  // 获得当前显示区域的分类id
  getMwealListShowheight: function (mealList) {
    var that = this;
    var topH = that.data.topPartH;
    var scrollViewH = that.data.bootomWrapH - that.data.bootomOperaH;
    for (var index in mealList) {
      var item = mealList[index];
      var w_h = topH + scrollViewH;
      if (item.bottom - topH < 0) {
        //小于0 说明已经滚出屏幕
        // console.log(item.dataset.id + '==>隐藏着呢');
        item.percent = 0;
      } else {
        if (item.bottom < w_h) {
          //底部距离小于 窗口高度 显示的部分高度直接为bottom值
          if ((item.bottom - topH) > item.height) {
            // console.log(item.dataset.id + '==>显示着呢，显示区域高度' + item.height);
            item.percent = (item.height / scrollViewH) * 100;
          } else {
            // console.log(item.dataset.id + '==>显示着呢，显示区域高度' + (item.bottom - topH));
            item.percent = ((item.bottom - topH) / scrollViewH) * 100;
          }
        } else {
          if (item.top - topH < 0) {
            //top值小于0且bottom>0 证明 当前元素顶部已经溢出屏幕 底部 还没有进入屏幕
            // console.log(item.dataset.id + '==>显示着呢，显示区域高为滚动区域高度' + scrollViewH);
            item.percent = 100;
          } else {
            if (item.top > w_h) {
              //top值大于窗口高度 证明当前元素的顶部 还没有进入屏幕
              // console.log(item.dataset.id + '==>隐藏着呢');
              item.percent = 0;
            } else {
              //top值小于等于窗口高度 说明当前元素顶部已经进入窗口 但底部还没有
              if ((w_h - item.top) > scrollViewH) {
                // console.log(item.dataset.id + '==>显示着呢，显示区域高为' + scrollViewH);
                item.percent = 100;
              } else {
                // console.log(item.dataset.id + '==>显示着呢，显示区域高为' + (w_h - item.top));
                item.percent = ((w_h - item.top) / scrollViewH) * 100;
              }
            }
          }
        }
      }
    }
    mealList.sort(function (a, b) {
      return b.percent - a.percent;
    })
    return mealList[0].dataset.id;
  },
  makeCall: function () {
    app.makeCall();
  }
})