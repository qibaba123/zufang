var WxParse = require('../../wxParse/wxParse.js');

var app = getApp()
Page({
  data: {
    title:''
  },
  onLoad: function (e) {
    var that = this;  
    var id = e.id;
    if (e.title.length>0){
      wx.setNavigationBarTitle({
        title: e.title
      })
      that.setData({
        title: e.title,
        id: e.id
      })
    }
    setTimeout(function(){
      console.log(app.globalData.requestUrl);
      //发起请求，获取列表列表
      wx.showToast({
        title: '加载中',
        icon: 'loading',
        mask: true,
        duration: 10000
      });
      wx.request({
        url: app.globalData.requestUrl,
        data: {
          map: 'applet_shop_service_details',
          id: id
        },
        success: function (res) {
          if (res.data.ec == 200) {
            console.log(res.data.data)
            that.setData({
              articleInfo: res.data.data
            })
            var article = res.data.data.content;
            // 富文本解析
            WxParse.wxParse('article', 'html', article, that, 5);
            if (that.data.title.length<=0){
              that.setData({
                title: res.data.data.title
              })
              wx.setNavigationBarTitle({
                title: res.data.data.title
              })
            }
          } else {
            console.log(res.data)
            app.errorTip(that, res.data.em, 2000);
          }
        },
        complete: function () {
          wx.hideToast();
        }
      });
    },1)
    
  },
  onShareAppMessage: function () {
    var title = that.data.title;
    var id = that.data.id;
    return {
      title: title,
      path: '/pages/articleDetail/articleDetail?id=' + id + '&title=' + title
    }
  }
})