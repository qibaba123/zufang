// pages/successtip/successtip.js
Page({
  data: {
  
  },
  onLoad: function (e) {
    var money = e.money;
    var that = this;
    that.setData({
      money:money
    })
  },
})