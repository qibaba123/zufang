var app = getApp()
Page({
  data: {
		curEdittype:'sex',
		isShowModal:false
  },
  onLoad: function (options) {
		var that = this;
		that.requestmemberInfo();
  },
	requestmemberInfo: function () {
		var that = this;
		var data = {};
		data.map = 'applet_three_member_info';
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					var memberInfo = res.data.data;
					app.globalData.memberInfo = memberInfo;
					if (app.globalData.memberInfo.mobile) {
						that.setData({
							mobile: app.globalData.memberInfo.mobile
						})
					}
          that.setData({
            memberInfo: app.globalData.memberInfo,
            getName: app.globalData.memberInfo.nickname,
            getSex: app.globalData.memberInfo.sex
          })
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
	onShow:function(){
		var that = this;
		console.log(app.globalData.memberInfo);
		that.setData({
			mobile: app.globalData.memberInfo.mobile ? app.globalData.memberInfo.mobile : ''
		})
	},
	showModal:function(e){
		var that = this;
		var curType = e.currentTarget.dataset.type;
		that.setData({
			isShowModal:true,
			curEdittype: curType
		})
	},
	hideModal: function () {
		var that = this;
		that.setData({
			isShowModal: false
		})
	},
	nameChange: function (e) {
		console.log('radio发生change事件，携带value值为：', e.detail.value)
		var that = this;
		that.setData({
			getName: e.detail.value
		})
	},
	sexChange: function (e) {
		console.log('radio发生change事件，携带value值为：', e.detail.value)
		var that = this;
		that.setData({
			getSex: e.detail.value
		})
	},
	confirmName: function () {
		var that = this;
		var getname = that.data.getName;
		var memberInfo = that.data.memberInfo;
		memberInfo.nickname = getname;
		console.log(getname);
		that.setData({
			memberInfo: memberInfo,
			isEdit: true
		})
		that.hideModal();
	},
	confirmSex:function(){
		var that = this;
		var getsex = that.data.getSex; 
		var memberInfo = that.data.memberInfo;
		memberInfo.sex = getsex;
		that.setData({
			memberInfo: memberInfo,
			isEdit:true
		})
		that.hideModal();
	},
	tomyPhone:function(){//我的手机号
		wx.navigateTo({
			url: '/pages/myPhone/myPhone'
		})
	},
	chooseImage:function(){
		var that = this;
		wx.showActionSheet({
			itemList: ['从相册中选择', '拍照'],
			itemColor: "#333",
			success: function (res) {
				if (!res.cancel) {
					if (res.tapIndex == 0) {
						that.chooseWxImage('album')
					} else if (res.tapIndex == 1) {
						that.chooseWxImage('camera')
					}
				}
			}
		})
	},
	chooseWxImage: function (type) {
		var that = this;
		wx.chooseImage({
			count: 1,
			sizeType: ['compressed'],
			sourceType: [type],
			success: function (res) {
				console.log(res);
				var temPath = res.tempFilePaths[0];
				that.upload_file(temPath);
			}
		})
	},
	// 上传头像到服务器
	upload_file: function (temPath) {
		var that = this;
		var memberInfo = that.data.memberInfo;
		wx.showToast({
			title: '上传中',
			icon: 'loading',
			duration: 10000,
			mask: true
		});
		wx.uploadFile({
			url: app.globalData.requestUrl + '?&map=applet_img_upload',
			filePath: temPath,
			name: 'image',
			success: function (res) {
				var data = JSON.parse(res.data);
				var realpath = app.globalData.domin + data.data.path;
				if (data.ec == 200) {
					console.log(realpath);
					memberInfo.avatar = realpath;
					that.setData({
						memberInfo: memberInfo,
						saveAvatar: data.data.path,
						isEdit: true
					})
				} else {
					wx.showModal({
						title: '提示',
						content: data.em,
						showCancel: false
					});
				}
			},
			complete: function () {
				wx.hideToast();
			}
		});
	},
	confirmModify:function(){
		var that = this;
		var isEdit = that.data.isEdit;
		var memberInfo = that.data.memberInfo;
		if (!isEdit){
			app.errorTip(that, "您尚未修改任何内容~", 2000);
			return;
		}
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: {
				map: 'applet_three_save_profile',
				avatar: memberInfo.avatar,
				nickname: memberInfo.nickname,
				sex: memberInfo.sex
			},
			success: function (res) {
				if (res.data.ec == 200) {
					console.log(res.data.data);
					app.errorTip(that, res.data.data, 2000);
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
			}
		});
	},
	getPhoneNumber: function (e) {
		console.log(!app.globalData.memberInfo);
		console.log(e.detail.errMsg)
		console.log(e.detail.iv)
		console.log(e.detail.encryptedData)
		var that = this;
		wx.login({
			success: function (res) {
				if (res.code) {
					var data = {
						map: 'applet_three_save_phone',
						code: res.code,
						encryptedData: e.detail.encryptedData,
						iv: e.detail.iv
					};
					if (!data.encryptedData) {
						that.tomyProfile();
					} else {
						that.requestMobile(data);
					}
				} else {
					console.log('获取用户登录态失败！' + res.errMsg)
				}
			}
		});
	},
	requestMobile: function (data) {
		var that = this;
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		console.log(app.globalData.requestUrl);
		console.log(data);
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					console.log(res.data.data);
					var mobile = res.data.data;
					var memberInfo = app.globalData.memberInfo;
					memberInfo.mobile = mobile;
					console.log(app.globalData.memberInfo);
					app.globalData.memberInfo = memberInfo;
					that.setData({
						mobile: mobile
					})
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
})