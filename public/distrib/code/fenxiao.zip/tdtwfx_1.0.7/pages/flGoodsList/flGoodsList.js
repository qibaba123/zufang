//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    shopGoods: [],
    showLoading: true,
    noMoretip: false,
    page: 0
  },
  onLoad: function () {

  },
  onShow: function () {
    app.setNavtitle('分类商品');
    var that = this;
    var page = that.data.page;
    var data = {};
    data.map = 'applet_goods_list';
    data.page = page;
    wx.getStorage({
      key: "flGoodId",
      success: function (res) {
        data.category = res.data;
        console.log(data);
        wx.request({
          url: app.globalData.requestUrl,
          data: data,
          success: function (res) {
            if (res.data.ec == 200) {
              console.log(res.data);
              var allArr = [];
              var initArr = that.data.shopGoods;
              var curArr = res.data.data.goods;
              var lastPageLength = curArr.length;
              if (page > 0) {
                allArr = initArr.concat(curArr);
              } else {
                allArr = res.data.data.goods;
              }
              that.setData({
                shopGoods: allArr,
                category: res.data.data.category
              })
              if (lastPageLength < 10) {
                that.setData({
                  noMoretip: true,
                  showLoading: false
                });
              }
              console.log(that.data.shopGoods);
            } else {
              console.log(res.data)
              if (page <= 0) {
                that.setData({
                  shopGoods: []
                })
              } else {
                that.setData({
                  noMoretip: true,
                  showLoading: false
                });
              }
            }
          },
          complete: function () {
            wx.hideToast();
            wx.stopPullDownRefresh();
          }
        });
      }
    })

  },
  onPullDownRefresh: function () {
    this.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    this.onShow();
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      that.onShow();
    }
  },
  goodDetail: function (e) {
    var goodId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../goodDetail/goodDetail?goodid=' + goodId
    })
  },
  cancel: function () {
    wx.navigateBack({
      delta: 1
    })
  }
})