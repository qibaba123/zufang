var WxParse = require('../../wxParse/wxParse.js');
//获取应用实例
var app = getApp()
Page({
  data: {
    autoplay: true,
    interval: 3000,
    duration: 1000,
    isShowModal: false,
    buyNumber: 1,
    modalOperaType: "",
    cartNumber: 0,
    goodDetail: {},
    chooseGuige: {},
    errorTip: {
      text: '',
      isShow: false
    }
  },
  onLoad: function (e) {
    var that = this;
    console.log(e);
    var goodId = e.goodid;
    that.setData({
      goodId: goodId,
    })
  },
  onShow: function () {
    var that = this;
    that.setData({
      customerService: app.globalData.customerService,
      isShowFenxiao: app.globalData.isdistrib,
      isapply: app.globalData.isapply
    })
    var goodId = that.data.goodId;
    setTimeout(function () {
      app.setVersion(that);
      //发起请求，获取列表列表
      wx.showToast({
        title: '加载中',
        icon: 'loading',
        mask: true,
        duration: 10000
      });
      wx.request({
        url: app.globalData.requestUrl,
        data: {
          map: 'applet_goods_detail',
          // suid: app.globalData.suid,
          gid: goodId
        },
        success: function (res) {
          if (res.data.ec == 200) {
            console.log(res.data.data);
            that.setData({
              goodDetail: res.data.data,
              cartNumber: res.data.data.cartNum
            })
            var article = that.data.goodDetail.detail;
            // 富文本解析
            WxParse.wxParse('article', 'html', article, that, 5);
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.em,
              showCancel: false
            });
          }
        },
        complete: function () {
          wx.hideToast();
        }
      });
    }, 1)
  },
  backShouye: function () {
    wx.reLaunch({
      url: '../index/index'
    })({
      delta: 1
    })
  },
  backCart: function () {
    wx.reLaunch({
      url: '../mycartTab/mycartTab'
    })
  },
  chooseGuige: function (e) {
    var id = e.target.dataset.id;
    var price = e.target.dataset.price;
    var stock = e.target.dataset.stock;
    var name = e.target.dataset.name;
    this.setData({
      chooseGuige: {
        id: id,
        price: price,
        stock: stock,
        name: name
      }
    })
  },
  addcart: function (e) {
    var that = this;
    if (!app.globalData.plumSession) {
      wx.showModal({
        title: '操作提示',
        content: '允许授权后才可进行其它操作哦',
        showCancel: false,
        confirmText: '确定',
        confirmColor: '#1AAD16',
        success: function (res) {
          if (res.confirm) {
            wx.reLaunch({
              url: '/pages/index/index'
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    } else {
      that.setData({
        isShowModal: true,
        modalOperaType: "addcart"
      })
    }
  },
  nowbuy: function () {
    var that = this;
    var that = this;
    if (!app.globalData.plumSession) {
      wx.showModal({
        title: '操作提示',
        content: '允许授权后才可进行其它操作哦',
        showCancel:false,
        confirmText: '确定',
        confirmColor: '#1AAD16',
        success: function (res) {
          if (res.confirm) {
            wx.reLaunch({
              url: '/pages/index/index'
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      console.log("暂未获取到信息");
    } else {
      that.setData({
        isShowModal: true,
        modalOperaType: "buy"
      })
    }
  },
  hideModal: function () {
    var that = this;
    that.setData({
      isShowModal: false
    })
  },
  changeNum: function (e) {
    var that = this;
    var type = e.currentTarget.dataset.type;
    var buyNum = parseInt(that.data.buyNumber);
    if (type == 'add') {
      buyNum++;
    } else {
      if (buyNum > 1) {
        buyNum--;
      } else {
        buyNum = 1;
      }
    }
    that.setData({
      buyNumber: buyNum
    })
  },
  confirmAddcart: function (e) {
    var that = this;
    var suid = app.globalData.suid;
    var gid = e.target.dataset.gid;
    var gfid = that.data.chooseGuige.id;
    var num = that.data.buyNumber;
    var isFormat = that.data.goodDetail.format.length > 0;
    var data = {
      map: 'applet_add_cart',
      // suid: suid,
      gid: gid,
      gfid: gfid,
      num: num
    }
    if (isFormat && !data.gfid) {
      app.errorTip(that, '请选择商品规格！', 2000);
    } else {
      //发起请求，获取列表列表
      // wx.showToast({
      //   title: '加载中',
      //   icon: 'loading',
      //   mask: true,
      //   duration: 10000
      // });
      wx.request({
        url: app.globalData.requestUrl,
        data: data,
        success: function (res) {
          if (res.data.ec == 200) {
            wx.showToast({
              title: res.data.data.msg,
              icon: 'success',
              duration: 2000,
            })
            that.hideModal();
            that.setData({
              cartNumber: res.data.data.cartNum
            })
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.em,
              showCancel: false
            });
          }
        },
        complete: function () {
          // wx.hideToast();
        }
      });
    }
  },
  nextStep: function () {
    var that = this;
    var gfid = that.data.chooseGuige.id;
    var isFormat = that.data.goodDetail.format.length > 0;
    var orderArr = [];
    var orderObj = {};
    orderObj.gid = that.data.goodDetail.id;
    orderObj.gfid = that.data.chooseGuige.id;;
    orderObj.num = that.data.buyNumber;
    orderArr.push(orderObj);
    var data  = {};
    data.map = 'applet_order_create';
    // data.suid = app.globalData.suid;
    data.buys = encodeURI(JSON.stringify(orderArr));
    console.log(app.globalData.requestUrl + '?map=' + data.map + '&suid=' + data.suid + '&buys=' + data.buys);
    if (isFormat && !gfid) {
      app.errorTip(that, '请选择商品规格！', 2000);
    } else {
      //发起请求，获取列表列表
      wx.showToast({
        title: '加载中',
        icon: 'loading',
        mask: true,
        duration: 10000
      });
      wx.request({
        url: app.globalData.requestUrl,
        data: data,
        success: function (res) {
          if (res.data.ec == 200) {
            console.log(res.data.data);
            wx.setStorage({
              key: "submitOrder",
              data: res.data.data,
              success: function () {
                wx.navigateTo({
                  url: '../waitBuyerPay/waitBuyerPay'
                })
              }
            })
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.em,
              showCancel: false
            });
          }
        },
        complete: function () {
          wx.hideToast();
        }
      });
    }
  },
  tiApplyFenxiao:function(){
    wx.navigateTo({
      url: '/pages/becomePartners/becomePartners'
    })
  },
  onShareAppMessage: function () {
    var that = this;
    var goodid = that.data.goodId;
    var goodName = that.data.goodDetail.name;
    console.log(goodName);
    return {
      title: goodName,
      path: '/pages/goodDetail/goodDetail?goodid=' + goodid
    }
  }
})