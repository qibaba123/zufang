var app = getApp()
Page({
  data: {
  },
  onLoad: function (options) {
		var that = this;
		that.setData({
			memberInfo: app.globalData.memberInfo
		})
		console.log(that.data.memberInfo);
		that.requestReference();
  },
	requestReference: function () {
		var that = this;
		var data = {};
		data.map = 'applet_three_my_refer';
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					that.setData({
						referenceInfo: res.data.data
					})
					app.globalData.memberInfo = res.data.data.member;
				} else {
					that.setData({
						referenceInfo:[]
					})
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
})