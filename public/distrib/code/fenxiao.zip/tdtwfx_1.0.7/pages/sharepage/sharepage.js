var app = getApp();
Page({
  data: {
    
  },
  onLoad: function (e) {
    var that = this;
    that.setData({
      sharedata: app.globalData.sharedata
    })
    if (!that.data.sharedata.shareUrl){
      return;
    }
    wx.showLoading({
      title: '加载中',
      mask: true,
      time: 100000
    })
    wx.downloadFile({
      url: that.data.sharedata.shareUrl,
      success: function (res) {
        console.log(res);
        that.setData({
          tempFilePathShow:res.tempFilePath
        })
        wx.hideLoading();
      }
    })
    console.log(that.data.sharedata);
  },
  onShareAppMessage: function () {
    var title = this.data.sharedata.shareTitle;
    var image = this.data.tempFilePathShow;
    console.log(image);
    return {
      title: title,
      imageUrl: image,
      path: '/pages/index/index'
    }
  },
  saveImage:function(){
    var that = this;
    var imgpath = this.data.sharedata.shareUrl;
    var tempFilePathShow = this.data.tempFilePathShow;
    if (imgpath.length<=0){
      app.errorTip(that, "海报图片不存在", 2000);
      return;
    }
    wx.showLoading({
      title: '正在保存',
      mask: true,
      time: 100000
    })
    wx.saveImageToPhotosAlbum({
      filePath: tempFilePathShow,
      success(res) {
        console.log(res);
        app.errorTip(that, "图片保存成功", 2000);
      },
      fail(f) {
        app.errorTip(that, "图片保存失败", 2000);
      },
      complete() {
        wx.hideLoading();
      }
    })
  }
})