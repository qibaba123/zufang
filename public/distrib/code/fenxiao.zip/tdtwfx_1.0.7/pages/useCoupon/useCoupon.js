//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
  onLoad:function(){
    var that = this;
    that.setData({
      userInfo: app.globalData.userInfo
    })
    wx.getStorage({
      key: "couponInfo",
      success: function (res) {
        console.log(res.data);
        that.setData({
          couponDetail: res.data.couponDetail,
          receiveList: res.data.receiveList
        })
      }
    })
  },
  
  // 优惠券
  toMycoupon: function () {
    wx.redirectTo({
      url: '/pages/myCoupon/myCoupon'
    })
  },
  toIndexuse: function () {
    wx.reLaunch({
      url: '/pages/index/index'
    })
  },
  toAllgoods: function (e) {
    var id = e.currentTarget.dataset.id;
    var type = e.currentTarget.dataset.type;
    wx.redirectTo({
      url: '/pages/searchList/searchList?id=' + id + '&type=' + type
    })
  },
  toShareCoupon: function (e) {
    var id = e.target.dataset.id;
    if (!id) {
      return;
    }
    wx.reLaunch({
      url: '/pages/shareCoupon/shareCoupon?id=' + id
    })
  },
})
