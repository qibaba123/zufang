var app = getApp()
Page({
  data: {
    isUnfold: true,
    name: '',
    phone: '',
    wechatnum: ''
  },
  onLoad: function (e) {
    var that = this;
    // var name = e.name;
    // app.setNavtitle(name);
  },
  onReady: function () {

  },
  onShow: function () {
    var that = this;
    app.setNavtitle('分销');
    that.requestPartners();
    that.requestFenxiaoCenter();
    that.setData({
      mobile: app.globalData.memberInfo ? app.globalData.memberInfo.mobile : ''
    })
    console.log(that.data.mobile);
  },
  toApplyFenxiao: function () {
    wx.navigateTo({
      url: '/pages/becomePartners/becomePartners'
    })
  },
  requestFenxiaoCenter: function () {
    var that = this;
    var data = {};
    data.map = 'applet_three_center_cfg';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          var memberInfo = res.data.data.member;
          if (app.globalData.memberInfo) {
            memberInfo = app.globalData.memberInfo;
          }
          app.globalData.memberInfo = memberInfo;
          if (app.globalData.memberInfo.mobile) {
            that.setData({
              mobile: app.globalData.memberInfo.mobile
            })
          }
          that.setData({
            fenxiaoInfo: res.data.data,
          })
          var level = res.data.data.level;
          if (level==3){
            var downlevel = res.data.data.down_level;
            console.log(downlevel);
            that.setData({
              down_level: res.data.data.down_level
            })
          } else if (level == 2){
            var downlevel=res.data.data.down_level;
            that.setData({
              down_level: downlevel.slice(0,2)
            })
          } else if (level == 1){
            var downlevel = res.data.data.down_level;
            that.setData({
              down_level: downlevel.slice(0, 1)
            })
          }

        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onPullDownRefresh: function () {
    var that = this;
    that.onShow();
  },
  clickUnfold: function () { // 展开折叠我的会员
    var that = this;
    that.setData({
      isUnfold: !that.data.isUnfold
    })
  },
  toMymember: function (e) {// 我的下级会员页面
    var title = e.currentTarget.dataset.title;
    var level = e.currentTarget.dataset.level;
    wx.navigateTo({
      url: '/pages/myMember/myMember?title=' + title + '&level=' + level
    })
  },
  toShareIncome: function (e) {// 我的分享收入
    wx.navigateTo({
      url: '/pages/shareIncome/shareIncome'
    })
  },
  toFanxianIncome: function (e) {// 我的返现收入
    wx.navigateTo({
      url: '/pages/fanxianIncome/fanxianIncome'
    })
  },
  toFenxiaoOrder: function (e) {// 分销订单
    wx.navigateTo({
      url: '/pages/fenxiaoOrder/fenxiaoOrder'
    })
  },
  tomyReference: function (e) {// 我的推荐人
    wx.navigateTo({
      url: '/pages/myReference/myReference'
    })
  },
  tomyProfile: function (e) {// 我的资料
    console.log(app.globalData.memberInfo);
    wx.navigateTo({
      url: '/pages/myProfile/myProfile'
    })
  },
  toextendCode: function (e) {// 推广二维码
    var that = this;
    that.requestExtendinfo();
  },
  requestExtendinfo: function () {
    var that = this;
    var memberInfo = app.globalData.memberInfo;
    console.log(memberInfo);
    var data = {};
    data.map = 'applet_three_share_code';
    data.path = '/pages/distributionTip/distributionTip?mid=' + memberInfo.mid;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            extendInfo: res.data.data
          })
          wx.setStorage({
            key: 'extendInfo',
            data: that.data.extendInfo,
            success: function () {
              wx.navigateTo({
                url: '/pages/extendCode/extendCode'
              })
            }
          })
          console.log(that.data.extendInfo);
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  toincomeWithdraw: function (e) {// 申请提现
    wx.navigateTo({
      url: '/pages/incomeWithdraw/incomeWithdraw'
    })
  },
  tosellRanklist: function (e) {// 销售排行榜
    wx.navigateTo({
      url: '/pages/sellRanklist/sellRanklist'
    })
  },
  getPhoneNumber: function (e) {
    console.log(!app.globalData.memberInfo);
    console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData)
    var that = this;
    wx.login({
      success: function (res) {
        if (res.code) {
          var data = {
            map: 'applet_three_save_phone',
            code: res.code,
            encryptedData: e.detail.encryptedData,
            iv: e.detail.iv
          };
          if (!data.encryptedData) {
            that.tomyProfile();
          } else {
            that.requestMobile(data);
          }
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  },
  requestMobile: function (data) {
    var that = this;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    console.log(app.globalData.requestUrl);
    console.log(data);
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          console.log(res.data.data);
          var mobile = res.data.data;
          var memberInfo = app.globalData.memberInfo;
          memberInfo.mobile = mobile;
          console.log(app.globalData.memberInfo);
          app.globalData.memberInfo = memberInfo;
          that.tomyProfile();
          // app.globalData.memberInfo = res.data.data.member;
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  requestPartners: function () {
    var that = this;
    var data = {};
    data.map = 'applet_three_configure';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            partners: res.data.data,
            isdistrib: res.data.data.isdistrib,
            isapply: res.data.data.isapply
          })
          app.globalData.isdistrib = res.data.data.isdistrib;
          app.globalData.isapply = res.data.data.isapply;
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  nameChange: function (e) {
    var that = this;
    that.setData({
      name: e.detail.value
    })
  },
  phoneChange: function (e) {
    var that = this;
    that.setData({
      phone: e.detail.value
    })
  },
  wechatnumChange: function (e) {
    var that = this;
    that.setData({
      wechatnum: e.detail.value
    })
  },
  submitRequest: function (e) {
    var that = this;
    var data = {
      map: 'applet_three_apply_distribution',
      realname: that.data.name,
      mobile: that.data.phone,
      wxno: that.data.wechatnum,
    }
    var hasname = that.data.partners.hasname;
    var hasphone = that.data.partners.hasphone;
    var haswx = that.data.partners.haswx;
    if (hasname == 1) {
      if (!data.realname) {
        app.errorTip(that, "请输入您的姓名", 2000);
        return;
      }
    }
    if (hasphone == 1) {
      var isMob = /^(0|86|17951)?(13[0-9]|15[012356789]|17[01678]|18[0-9]|14[57])[0-9]{8}$/;
      if (!isMob.test(data.mobile)) {
        app.errorTip(that, "请输入正确的手机号", 2000);
        return;
      }
    }
    if (haswx == 1) {
      if (!data.wxno) {
        app.errorTip(that, "请输入您的微信号", 2000);
        return;
      }
    }
    console.log(data);
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          app.errorTip(that, res.data.data.msg, 2000);
          that.setData({
            name: '',
            phone: '',
            wechatnum: '',
            isapply: res.data.data.isapply
          })
          app.globalData.isapply = res.data.data.isapply;
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  }
})