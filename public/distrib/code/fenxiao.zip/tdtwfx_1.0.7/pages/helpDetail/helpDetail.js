var WxParse = require('../../wxParse/wxParse.js');

var app = getApp()
Page({
  data: {
    userInfo: {}
  },
  onLoad: function () {
    console.log('onLoad');
    var that = this;
    that.setData({
      mobile: app.globalData.telphone
    })
    var that = this;  
    wx.getStorage({
      key: "helpDetail",
      success: function (res) {
        var article = res.data;
        // article = article.replace(/\/span|/strong/g, "/text");
        // article = article.replace(/\<p/g, "<view").replace(/\p>/g, "view>").replace(/\<span|<strong/g, "<text");
        
        console.log(res);
        // 富文本解析
        WxParse.wxParse('article', 'html', article, that, 5);
      }
    })
  },
  makeCall: function () {
    app.makeCall();
    // wx.showModal({
    //   title: '',
    //   content: '0371-86258375',
    //   confirmText:'拨打',
    //   confirmColor:'#48C23D',
    //   success: function (res) {
    //     if (res.confirm) {
    //       wx.makePhoneCall({
    //         phoneNumber: '0371-86258375',
    //         success: function () {
    //           console.log("拨打电话成功！")
    //         },
    //         fail: function () {
    //           console.log("拨打电话失败！")

    //         }
    //       })
    //     }
    //   }
    // })
  }
})