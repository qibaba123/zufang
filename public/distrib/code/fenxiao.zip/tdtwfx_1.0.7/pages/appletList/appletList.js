//获取应用实例
var app = getApp()
Page({
  data: {
   
  },
  onLoad: function () {
    var that = this;
    that.requestApplet();
  },
  requestApplet: function () {
    var that = this;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_applet_jump_list'
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          console.log(res.data.data)
          that.setData({
            appletInfo: res.data.data
          })
          
        } else {
          console.log(res.data)
          that.setData({
            appletInfo: ""
          })
          // app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onShow: function () {
    var that = this;
    app.setNavtitle('导航');
  },
  onPullDownRefresh:function(){
    this.requestApplet();
  },
  openApplet: function (e) {
    var path = e.currentTarget.dataset.path;
    var appid = e.currentTarget.dataset.appid;
    console.log(path);
    console.log(appid);
    wx.navigateToMiniProgram({
      appId: appid,
      path: path,
      envVersion: 'release',
      success(res) {
        // 打开成功
      }
    })
  },
  onShareAppMessage: function () {
    var that = this;
    return {
      title: "小程序列表",
      path: '/pages/appletList/appletList'
    }
  }
})
