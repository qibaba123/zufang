
var app = getApp()
Page({
  data: {
    noscoreUrl: '../../images/icon_noscore.png',
    scoredUrl: '../../images/icon_scored.png',
    isShowModal: false,
    bigImgShow: {},
    shopFhScore: 0,
    shopFwScore: 0,
    errorTip: {
      text: '',
      isShow: false
    }
  },
  onLoad: function (e) {
    console.log('onLoad');
    var that = this;
    // that.setData({
    //   orderid: e.orderid
    // })
    // console.log(that.data.orderid)
    var tid = e.orderid;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_comment',
        // suid: app.globalData.suid,
        tid: tid
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          var orderinfo = res.data.data;
          for (var i = 0; i <orderinfo.goods.length; i++) {
           orderinfo.goods[i].commentTxt = "";
           orderinfo.goods[i].score = 0;
           orderinfo.goods[i].imgList = [];
          }
          that.setData({
            orderinfo: orderinfo
          })
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  onShow: function () {
    var that = this;
    var tid = that.data.orderid;
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  showBigimg: function (e) {
    var that = this;
    var src = e.target.dataset.src;
    var gid = e.target.dataset.gid;
    var curIndex = e.target.dataset.index;
    var orderinfo = that.data.orderinfo;
    var imgLength;
    for (var i = 0; i < orderinfo.goods.length; i++) {
      if (orderinfo.goods[i].gid == gid) {
        imgLength = orderinfo.goods[i].imgList.length;
      }
    }
    var obj = {};
    obj.curIndex = curIndex;
    obj.sumLength = imgLength;
    obj.src = src;
    that.setData({
      isShowModal: true,
      bigImgShow: obj
    })
  },
  previewImg: function (e) {
    var that = this;
    var current = e.target.dataset.src;
    var gid = e.target.dataset.gid;
    var orderinfo = that.data.orderinfo;
    var imgUrls;
    for (var i = 0; i < orderinfo.goods.length; i++) {
      if (orderinfo.goods[i].gid == gid) {
        imgUrls = orderinfo.goods[i].imgList;
      }
    }
    wx.previewImage({
      current: current,
      urls: imgUrls
    })
  },
  goodScore: function (e) {
    var that = this;
    var gid = e.target.dataset.gid;
    var score = e.target.dataset.score;
    var orderinfo = that.data.orderinfo;
    for (var i = 0; i < orderinfo.goods.length; i++) {
      if (orderinfo.goods[i].gid == gid) {
        orderinfo.goods[i].score = score;
      }
    }
    that.setData({
      orderinfo: orderinfo
    })
    console.log(gid + "/" + score);
  },
  commentChange: function (e) {
    var that = this;
    var gid = e.target.dataset.gid;
    var orderinfo = that.data.orderinfo;
    for (var i = 0; i < orderinfo.goods.length; i++) {
      if (orderinfo.goods[i].gid == gid) {
        orderinfo.goods[i].commentTxt = e.detail.value;
      }
    }
    that.setData({
      orderinfo: orderinfo
    })
  },
  shopScore: function (e) {
    var that = this;
    var type = e.target.dataset.type;
    if (type == 'Fh') {
      var score = e.target.dataset.score;
      console.log(score);
      that.setData({
        shopFhScore: score
      })
    } else if (type == 'Fw') {
      var score = e.target.dataset.score;
      console.log(score);
      that.setData({
        shopFwScore: score
      })
    }
  },
  uploadImg: function (e) {
    var that = this;
    var gid = e.currentTarget.dataset.gid;
    var orderinfo = that.data.orderinfo;
    // var imgCount;
    // for (var i = 0; i < orderinfo.goods.length; i++) {
    //   if (orderinfo.goods[i].gid == gid) {
    //     if (orderinfo.goods[i].imgList) {
    //       imgCount = 5 - orderinfo.goods[i].imgList.length;
    //     } else {
    //       imgCount = 5;
    //     }
    //   }
    // }
    // console.log(imgCount);
    wx.chooseImage({
      count: 1,
      success: function (res) {
        var tempFilePaths = res.tempFilePaths;
        console.log(tempFilePaths)
        wx.showToast({
          title: '正在上传',
          icon: 'loading',
          duration: 10000,
          mask: true
        });
        var url = app.globalData.requestUrl + '?map=applet_img_upload';
        console.log(url);
        wx.uploadFile({
          url: url,
          filePath: tempFilePaths[0],
          name: 'image',
          formData: {
            'user': 'zhaoyang'
          },
          success: function (res) {
            var pathData = JSON.parse(res.data);
            var path = pathData.data.path;
            console.log(pathData);
            var realpath = app.globalData.domin + path;
            if (pathData.ec == 200) {
              for (var i = 0; i < orderinfo.goods.length; i++) {
                if (orderinfo.goods[i].gid == gid) {
                  var imgArr;
                  if (orderinfo.goods[i].imgList) {
                    imgArr = orderinfo.goods[i].imgList;
                  } else {
                    imgArr = [];
                  }
                  imgArr.push(realpath);
                  console.log(imgArr);
                  orderinfo.goods[i].imgList = imgArr;
                }
              }
              console.log(realpath);
              that.setData({
                orderinfo: orderinfo
              })
              console.log(that.data.orderinfo.goods)
            } else {
              wx.showModal({
                title: '提示',
                content: data.em,
                showCancel: false
              });
            }
          },
          complete: function () {
            wx.hideToast();
          }
        })
      }
    })
  },
  delUploadImg: function (e) {
    var that = this;
    var gid = e.target.dataset.gid;
    var index = e.target.dataset.index;
    var orderinfo = that.data.orderinfo;
    for (var i = 0; i < orderinfo.goods.length; i++) {
      if (orderinfo.goods[i].gid == gid) {
        orderinfo.goods[i].imgList.splice(index, 1);
      }
    }
    that.setData({
      orderinfo: orderinfo
    })
    console.log(gid);
    console.log(index);
  },
  saveEvaluate: function (e) {
    var that = this;
    var orderInfo = that.data.orderinfo;
    var data = {};
    var goods = [];
    data.map = 'applet_order_comment_save';
    // data.suid = app.globalData.suid;
    data.tid = orderInfo.tid;
    data.speed = that.data.shopFhScore;
    data.attitude = that.data.shopFwScore;
    for (var i = 0; i < orderInfo.goods.length; i++) {
      var obj = {};
      obj.toid = orderInfo.goods[i].gid;
      if (orderInfo.goods[i].score>0){
        obj.score = orderInfo.goods[i].score;
      }else{
        app.errorTip(that, "商品评分不能为空", 2000);
        return;
      }
      obj.content = orderInfo.goods[i].commentTxt;
      obj.image = orderInfo.goods[i].imgList;
      goods.push(obj)
    }
    data.goods = encodeURI(JSON.stringify(goods));
    // data.goods = goods;
    if (data.speed>0){
      if (data.attitude>0){
        console.log(data);
        //发起请求，获取列表列表
        wx.showToast({
          title: '加载中',
          icon: 'loading',
          mask: true,
          duration: 10000
        });
        wx.request({
          url: app.globalData.requestUrl,
          data: data,
          success: function (res) {
            if (res.data.ec == 200) {
              console.log(res.data.data);
              wx.showModal({
                title: '提示',
                content: res.data.data.msg,
                showCancel: false,
                success:function(){
                  wx.navigateBack({
                    delta: 1
                  })
                }
              });
            } else {
              app.errorTip(that, res.data.em, 2000);
            }
          },
          complete: function () {
            wx.hideToast();
          }
        });
      }else{
        app.errorTip(that, "店铺服务态度评分不能为空", 2000);
      }
    }else{
      app.errorTip(that, "店铺发货速度评分不能为空", 2000);
    }
  }
})