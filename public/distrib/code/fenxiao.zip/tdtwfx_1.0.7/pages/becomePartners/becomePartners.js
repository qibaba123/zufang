var app = getApp()
Page({
  data: {
		isUnfold:true,
    name: '',
    phone: '',
    wechatnum: ''
  },
  onLoad: function (options) {
    var that = this;
    that.requestPartners();
  },
  onReady: function () {
  
  },
  onShow: function () {
    app.setNavtitle('成为分销商');
  },
  requestPartners: function () {
    var that = this;
    var data = {};
    data.map = 'applet_three_configure';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            partners: res.data.data,
            isapply: res.data.data.isapply
          })

        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  nameChange:function(e){
    var that = this;
    that.setData({
      name:e.detail.value
    })
  },
  phoneChange: function (e) {
    var that = this;
    that.setData({
      phone: e.detail.value
    })
  },
  wechatnumChange: function (e) {
    var that = this;
    that.setData({
      wechatnum: e.detail.value
    })
  },
  submitRequest:function(e){
    var that = this;
    var data = {
      map:'applet_three_apply_distribution',
      realname: that.data.name,
      mobile: that.data.phone,
      wxno: that.data.wechatnum,
    }
    var hasname = that.data.partners.hasname;
    var hasphone = that.data.partners.hasphone;
    var haswx = that.data.partners.haswx;
    if (hasname==1){
      if (!data.realname) {
        app.errorTip(that, "请输入您的姓名", 2000);
        return;
      }
    }
    if (hasphone==1){
      var isMob = /^(0|86|17951)?(13[0-9]|15[012356789]|17[01678]|18[0-9]|14[57])[0-9]{8}$/;
      if (!isMob.test(data.mobile)) {
        app.errorTip(that, "请输入正确的手机号", 2000);
        return;
      }
    }
    if (haswx == 1) {
      if (!data.wxno) {
        app.errorTip(that, "请输入您的微信号", 2000);
        return;
      }
    }
    console.log(data);
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          app.errorTip(that, res.data.data.msg, 2000);
          that.setData({
            name: '',
            phone: '',
            wechatnum: '',
            isapply: res.data.data.isapply
          })
          app.globalData.isdistrib = res.data.data.isdistrib;
          app.globalData.isapply = res.data.data.isapply;
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  }
})