// pages/Generalreservation/Generalreservation.js
var app = getApp();
Page({

  onShow: function () {
    app.setNavtitle('预约');
    var that = this;
    if (!app.globalData.plumSession) {
      wx.reLaunch({
        url: '/pages/index/index'
      })
    }
    that.setData({
      customerService: app.globalData.customerService
    })
    
  },
  onLoad: function () {
    var that = this;
    that.loadData();
    if (!app.globalData.plumSession) {
      app.wechatSq();
    }
  },
  onPullDownRefresh: function () {
    var that = this;
    that.loadData();
  },
  loadData: function () {
    var that = this;
    if (!that.data.info) {
      wx.showLoading({
        title: '加载中...',
      })
    }
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_appointment_index'
      },
      // url: app.getRequestUrl("/applet.php?map=applet_appointment_index"),
      success: function (res) {
        console.log(res)
        if (res.data.ec == 200) {
          that.setData({
            info: res.data.data
          })
          // wx.setNavigationBarTitle({
          //   title: res.data.data.template.title,
          // })
        } else {

        }
      },
      fail: function () {
        console.log("fail")
      },
      complete: function () {
        wx.hideLoading()
        wx.stopPullDownRefresh()
      }
    })
  },
  noteableClick: function (e) {
    if(!app.globalData.plumSession) {
      app.wechatSq();
      return;
    }
    var id = e.currentTarget.dataset.id;
    if (id == 0) {
      return;
    }
    wx.navigateTo({
      url: '../informationDetail/informationDetail?id=' + id + "&title=" + e.currentTarget.dataset.title,
    })
  },
  cellClick: function (e) {
    if (!app.globalData.plumSession) {
      app.wechatSq();
      return;
    }
    var id = e.currentTarget.dataset.id;
    if (!id || id.length == 0) {
      return;
    }
    wx.navigateTo({
      url: '../Generalreservationdetail/Generalreservationdetail?id=' + id,
    })
  },
  myorderClick: function () {
    if (!app.globalData.plumSession) {
      app.wechatSq();
      return;
    }
    wx.navigateTo({
      url: '../Generalreservationlist/Generalreservationlist',
    })
  },
  makeCall:function(e){
    var mobile = e.currentTarget.dataset.mobile;
    app.makeCallphone(mobile);
  },
  seemap: function (e) {
    var latitude = e.currentTarget.dataset.lat;
    var longitude = e.currentTarget.dataset.lng;
    var address = e.currentTarget.dataset.address;
    var name = e.currentTarget.dataset.name;
    wx.openLocation({
      latitude: Number(latitude),
      longitude: Number(longitude),
      name: name,
      address: address,
      scale: 18
    })
  },
  //转发
  onShareAppMessage: function () {
    var title = app.name;
    return {
      // title: title,
      path: '/pages/index/index'
    }
  }
})