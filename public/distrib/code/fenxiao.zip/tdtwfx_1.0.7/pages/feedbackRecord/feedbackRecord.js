var WxParse = require('../../wxParse/wxParse.js');

var app = getApp();
var timer;
Page({
  data: {
    second: 0,
    remainTime: '',
    isShowModal:false,
    errorTip: {
      text: '',
      isShow: false
    },
    tkOrderid: "",
    tkMoney: "",
    tkReason: "",
    tkContact: "",
    wqInfo:{}
  },
  onLoad:function(e){
    var that = this;
    console.log(e.orderid);
    that.setData({
      orderId: e.orderid
    })
  },
  onShow: function () {
    var that = this;
    var data = {};
    data.map = 'applet_order_refund_record';
    data.tid = that.data.orderId;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data);
          that.setData({
            wqInfo: res.data.data,
            second: res.data.data.time
          })
          countdown(that);
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  applyTuikuan: function (e) {
    var that = this;
    var orderId = that.data.wqInfo.tid;
    var total = that.data.wqInfo.orderTotal;
    that.setData({
      tkMoney: total,
      tkReason: "",
      tkContact: "",
      isShowModal: true,
      tkOrderid: orderId
    })
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  cancelTk: function (e) {
    var that = this;
    var tid = that.data.wqInfo.tid;
    wx.showModal({
      title: '',
      cancelText: '再考虑下',
      confirmText: '确认',
      content: '确认撤销维权吗？',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 3000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_refund_cancel',
              // suid: app.globalData.suid,
              tid: tid
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                wx.navigateBack({
                  delta: 1
                })
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  tkMoneyChange: function (e) {
    this.setData({
      tkMoney: e.detail.value
    })
  },
  tkReasonChange: function (e) {
    this.setData({
      tkReason: e.detail.value
    })
  },
  tkContactChange: function (e) {
    this.setData({
      tkContact: e.detail.value
    })
  },
  submitTkapply: function () {
    var that = this;
    var data = {};
    data.map = 'applet_order_refund';
    // data.suid = app.globalData.suid,
    data.tid = that.data.tkOrderid;
    data.money = that.data.tkMoney;
    data.reason = that.data.tkReason;
    data.contact = that.data.tkContact;

    if (data.money == "") {
      app.errorTip(that, "请输入退款金额", 2000);
    } else {
      if (data.reason == "") {
        app.errorTip(that, "请输入退款原因", 2000);
      } else {
        if (data.contact == "") {
          app.errorTip(that, "请输入您的联系方式", 2000);
        } else {
          console.log(data);
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: data,
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onShow();
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              that.setData({
                isShowModal: false
              })
              wx.hideToast();
            }
          });
        }
      }
    }
  }
})

/* 秒级倒计时 */
function countdown(that) {
  var second = that.data.second;
  var remainDay = parseInt(second / 60 / 60 / 24);
  var remainHour = parseInt(second / 60 / 60) % 24;
  var remainMinute = parseInt(second / 60) % 60;
  remainMinute = remainMinute < 10 ? ('0' + remainMinute) : remainMinute;
  var remainSecond = second % 60;
  remainSecond = remainSecond < 10 ? ('0' + remainSecond) : remainSecond;
  // that.setData({
  //   remainTime: remainDay + '天' + remainHour + '小时' + remainMinute + '分' + remainSecond + '秒'
  // });
  that.setData({
    remainDay: remainDay,
    remainHour: remainHour,
    remainMinute: remainMinute,
    remainSecond: remainSecond
  });
  if (second == 0) {
    that.setData({
      second: 0
    });
    return;
  }
  clearTimeout(timer);
  timer = setTimeout(function () {
    var second = that.data.second;
    var remainDay = parseInt(second / 60 / 60 / 24);
    var remainHour = parseInt(second / 60 / 60);
    var remainMinute = parseInt(second / 60);
    var remainSecond = second % 60;
    remainSecond = remainSecond < 10 ? ('0' + remainSecond) : remainSecond;
    that.setData({
      second: second - 1,
      remainTime: remainDay + '天' + remainHour + '小时' + remainMinute + '分' + remainSecond + '秒'
    });
    countdown(that);
  }, 1000);
}