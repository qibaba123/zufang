var app = getApp()
Page({
  data: {
    isShowModal: false,
    modalType: '',
    orderfenlei: 'all',
    showLoading: true,
    noMoretip: false,
    page: 0,
    errorTip: {
      text: '',
      isShow: false
    },
    // orderList:[]
    tkOrderid: "",
    tkMoney: "",
    tkReason: "",
    tkContact: ""
  },
  onLoad: function () {
    var that = this
    wx.getStorage({
      key: 'shopInfoname',
      success: function (res) {
        that.setData({
          shopname: res.data
        })
      }
    })
    app.setVersion(that);
    that.requestOrder();
  },
  onShow: function () {
    app.setNavtitle('我的订单');
    var that = this;
    that.setData({
      customerService: app.globalData.customerService
    })
    if (!app.globalData.plumSession) {
      wx.reLaunch({
        url: '/pages/index/index'
      })
    }
  },
  requestOrder:function(){
    var that = this;
    var page = that.data.page;
    var status = that.data.orderfenlei;
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_list',
        status: status,
        page: page
      },
      success: function (res) {
        console.log(page);
        if (res.data.ec == 200) {
          var allArr = [];
          var initArr = that.data.orderList;
          var curArr = res.data.data;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data;
          }
          that.setData({
            orderList: allArr
          })
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          console.log(that.data.orderList);
        } else {
          console.log(page);
          if (page <= 0) {
            that.setData({
              orderList: [],
              showLoading: false
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          console.log(res.data);
        }
      },
      complete: function () {
        wx.stopPullDownRefresh();
      }
    });
  },
  orderDetail: function (e) {
    var orderId = e.currentTarget.dataset.orderid;
    wx.navigateTo({
      url: '../orderDetail/orderDetail?orderid=' + orderId
    })
  },
  chooseFenlei: function (e) {
    var that = this;
    var fenlei = e.target.dataset.fenlei;
    that.setData({
      orderList:null,
      orderfenlei: fenlei,
      page: 0,
      noMoretip: false,
      showLoading: true
    })
    that.requestOrder();
  },
  onPullDownRefresh: function () {
    var that = this;
    that.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    that.requestOrder();
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      that.requestOrder();
    }
  },
  cancelOrder: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    wx.showModal({
      title: '',
      cancelText: '再考虑下',
      confirmText: '取消订单',
      content: '订单还未付款，确认取消吗？',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_cancel_order',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, '订单已取消成功~', 2000);
                that.onPullDownRefresh();
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  seeWuliu: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_fetch_track',
        // suid: app.globalData.suid,
        tid: orderId
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data.track.Traces);
          that.setData({
            modalType: 'wuliu',
            isShowModal: true,
            logisticsInfo: res.data.data.track.Traces
          })
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  remindSend: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_order_remind',
        // suid: app.globalData.suid,
        tid: orderId
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          app.errorTip(that, res.data.data.msg, 2000);
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  tkMoneyChange: function (e) {
    this.setData({
      tkMoney: e.detail.value
    })
  },
  tkReasonChange: function (e) {
    this.setData({
      tkReason: e.detail.value
    })
  },
  tkContactChange: function (e) {
    this.setData({
      tkContact: e.detail.value
    })
  },
  applyTuikuan: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    that.setData({
      modalType: 'tuikuan',
      tkMoney: "",
      tkReason: "",
      tkContact: "",
      isShowModal: true,
      tkOrderid: orderId
    })

  },
  submitTkapply: function () {
    var that = this;
    var data = {};
    data.map = 'applet_order_refund';
    // data.suid = app.globalData.suid,
    data.tid = that.data.tkOrderid;
    data.money = that.data.tkMoney;
    data.reason = that.data.tkReason;
    data.contact = that.data.tkContact;

    if (data.money == "") {
      app.errorTip(that, "请输入退款金额", 2000);
    } else {
      if (data.reason == "") {
        app.errorTip(that, "请输入退款原因", 2000);
      } else {
        if (data.contact == "") {
          app.errorTip(that, "请输入您的联系方式", 2000);
        } else {
          console.log(data);
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: data,
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data);
                app.errorTip(that, res.data.data.msg, 2000);
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              that.setData({
                isShowModal: false
              })
              wx.hideToast();
            }
          });
        }
      }
    }
  },
  confirmReceiving: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    wx.showModal({
      title: '',
      cancelText: '还没收到',
      confirmText: '确认收货',
      content: '确认收到货物了吗？',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_confirm_accept',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onPullDownRefresh();
              } else {
                wx.showModal({
                  title: '提示',
                  content: res.data.em,
                  showCancel: false
                });
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  goodEvalute: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    wx.navigateTo({
      url: '../evaluate/evaluate?orderid=' + orderId
    })
  },
  payorder: function (e) {
    var orderId = e.target.dataset.id;
    wx.navigateTo({
      url: '../orderDetail/orderDetail?orderid=' + orderId
    })
  },
  extendReceiving: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    wx.showModal({
      title: '确认延长收货时间？',
      cancelText: '取消',
      confirmText: '确认',
      content: '每个订单只能延长收货一次哦~',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_extended_delivery',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    
  },
  delOrder: function (e) {
    var that = this;
    var orderId = e.target.dataset.id;
    wx.showModal({
      title: '删除提示',
      cancelText: '取消',
      confirmText: '确认',
      content: '确认删除该订单吗',
      confirmColor: '#1AAD16',
      success: function (res) {
        if (res.confirm) {
          //发起请求，获取列表列表
          wx.showToast({
            title: '加载中',
            icon: 'loading',
            mask: true,
            duration: 10000
          });
          wx.request({
            url: app.globalData.requestUrl,
            data: {
              map: 'applet_order_delete',
              // suid: app.globalData.suid,
              tid: orderId
            },
            success: function (res) {
              if (res.data.ec == 200) {
                console.log(res.data.data);
                app.errorTip(that, res.data.data.msg, 2000);
                that.onShow();
              } else {
                app.errorTip(that, res.data.em, 2000);
              }
            },
            complete: function () {
              wx.hideToast();
            }
          });
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  makeCall: function () {
    app.makeCall();
  }
})