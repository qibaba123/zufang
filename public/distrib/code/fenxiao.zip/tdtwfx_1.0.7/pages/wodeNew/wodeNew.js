var app = getApp()
Page({
  data: {
    showType: 'changeTel',
    isShowModal: false,
    userInfo: {}
  },
  onLoad: function () {
    var that = this
    that.setData({
      userInfo: app.globalData.userInfo
    })
    console.log(that.data.userInfo);
    app.setVersion(that);
  },
  onShow:function(){
    var that = this;
    app.setNavtitle('我');

    if (!app.globalData.plumSession) {
      wx.reLaunch({
        url: '/pages/index/index'
      })
    }
    that.requestMine();
  },
  requestMine:function(){
    var that = this;
    var data = {};
    data.map = 'applet_member_center_cfg';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            mineInfo: res.data.data
          })
          // wx.setNavigationBarTitle({
          //   title: res.data.data.title
          // })
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  myAddress: function () {
    wx.navigateTo({
      url: '../addressManage/addressManage'
    })
  },
  openHelpCenter: function () {
    wx.navigateTo({
      url: '../helpCenter/helpCenter'
    })
  },
  openOrder: function (e) {
    var type = e.currentTarget.dataset.type;
    console.log(type)
    wx.navigateTo({
      url: '../myorder/myorder?type='+type
    })
  },
  mycart:function(){
    wx.navigateTo({
      url: '../mycart/mycart'
    })
  },
  contactKefu: function () {
    console.log('检测是否已登录');
    var that = this;
    wx.showModal({
      title: '',
      content: '联系客服请先登录天店通账号哦~',
      cancelText: '我知道了',
      confirmText: '立即登录',
      confirmColor: '#48C23D',
      success: function (res) {
        if (res.confirm) {
          that.setData({
            isShowModal: true
          })
        }
      }
    })
  },
  hideModal: function () {
    this.setData({
      isShowModal: false
    })
  },
  showOpera: function (e) {
    var type = e.target.dataset.type;
    var showtype = "";
    var that = this;
    if (type == 'confirmTel') {
      var isReg = true;
      if (isReg) {
        showtype = 'logPart';
      } else {
        showtype = 'regPart';
      }
      console.log("检测是否注册");
    } else {
      showtype = type;
    }
    that.setData({
      showType: showtype
    })
  },
  // 优惠券
  toMycoupon: function () {
    wx.navigateTo({
      url: '/pages/myCoupon/myCoupon'
    })
  },
  toDistributionCenter:function(e){
    var name = e.currentTarget.dataset.name;
    wx.navigateTo({
      url: '/pages/distributionCenter/distributionCenter?name='+name,
    })
  },
  makeCall: function () {
    app.makeCall();
  },
 
})