// pages/Generalshare/Generalshare.js
Page({


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})