var app = getApp()
Page({
  data: {
    nocheckIconUrl: '../../images/icon_nocheck.png',
    checkIconUrl: '../../images/icon_checked_red.png',
    shopname: '',
    checkedAll: false,
    delDisabled: false,
    isEdit: false,
    // cartList: [],
    sumPrice: 0,
    showLoading: true,
    noMoretip: false,
    page: 0,
    errorTip: {
      text: '',
      isShow: false
    }
  },


  onLoad: function () {
    var that = this;
    var page = that.data.page;
    //发起请求，获取列表列表
    // wx.showToast({
    //   title: '加载中',
    //   icon: 'loading',
    //   mask: true,
    //   duration: 10000
    // });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_cart_list',
        page: page
      },
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          var allArr = [];
          var initArr = that.data.cartList;
          var curArr = res.data.data;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data;
          }
          that.setData({
            cartList: allArr,
            checkedAll:false,
            sumPrice:0
          })
          console.log(that.data.checkedAll)
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
        } else {
          if (page <= 0) {
            that.setData({
              cartList: [],
              checkedAll: false,
              sumPrice: 0
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onShow: function () {
    app.setNavtitle('购物车');
    var that = this;
    if (!app.globalData.plumSession) {
      wx.reLaunch({
        url: '/pages/index/index'
      })
    }
    var that = this;
    wx.getStorage({
      key: 'shopInfoname',
      success: function (res) {
        that.setData({
          shopname: res.data
        })
      }
    })
    that.onPullDownRefresh();
    console.log(app.globalData.requestUrl);
    app.setVersion(that);
  },
  isCheckedAll: function () {
    var that = this;
    var checkState = !that.data.checkedAll;
    var delState;
    if (checkState) {
      delState = true;
    } else {
      delState = false;
    }
    that.setData({
      checkedAll: checkState,
      delDisabled: delState
    })
    var cartList = that.data.cartList;
    for (var i = 0; i < cartList.length; i++) {
      if (checkState) {
        cartList[i].checked = true;
      } else {
        cartList[i].checked = false;
      }
    }
    that.setData({
      cartList: cartList
    })
    that.getSumprice();
  },
  isedit: function (e) {
    var that = this;
    var type = e.target.dataset.type;
    if (type == 'finish') {
      that.getSumprice();
    }
    var isedit = !that.data.isEdit;
    var cartList = that.data.cartList;
    var checkLength = 0;
    for (var i = 0; i < cartList.length; i++) {
      if (cartList[i].checked) {
        checkLength++
      }
    }
    console.log(checkLength);
    var delDisabled;
    if (checkLength>0){
      delDisabled = true;
    }else{
      delDisabled = false;
    }
    that.setData({
      isEdit: isedit,
      delDisabled
    })
  },
  changeNum: function (e) {
    var that = this;
    var type = e.currentTarget.dataset.type;
    // var suid = app.globalData.suid;
    var cartid = e.currentTarget.dataset.cartid;
    var gfid = e.currentTarget.dataset.gfid;
    var gid = e.currentTarget.dataset.gid;
    var cartList = that.data.cartList;
    var curIndex = '';
    for (var i = 0; i < cartList.length; i++) {
      if (cartid == cartList[i].id) {
        curIndex = i;
      }
    }
    var curNum = cartList[curIndex].num;
    if (type == 'add') {
      curNum++;
    } else {
      if (curNum > 1) {
        curNum--;
      } else {
        curNum = 1;
        return;
      }
    }
    cartList[curIndex].num = curNum;
    that.setData({
      cartList: cartList
    })

    var num = curNum;
    var data = {
      map: 'applet_add_cart',
      gid: gid,
      gfid: gfid,
      num: num
    }
    if (curNum >= 1) {
      //发起请求，获取列表列表
      // wx.showToast({
      //   title: '加载中',
      //   icon: 'loading',
      //   mask: true,
      //   duration: 10000
      // });
      wx.request({
        url: app.globalData.requestUrl,
        data: data,
        success: function (res) {
          if (res.data.ec == 200) {
            // console.log(res.data.data);
            // wx.showToast({
            //   title: res.data.data.msg,
            //   icon: 'success',
            //   duration: 2000,
            // })
            that.getSumprice();
          } else {
            wx.showModal({
              title: '提示',
              content: res.data.em,
              showCancel: false
            });
          }
        },
        complete: function () {
          wx.hideToast();
        }
      });
    }
  },
  cartGoodChecked: function (e) {
    var that = this;
    var cartid = e.currentTarget.dataset.cartid;
    var cartList = that.data.cartList;
    var curIndex = '';
    var checkedNum = 0;
    var checkedAll;
    var delDisable;
    for (var i = 0; i < cartList.length; i++) {
      if (cartid == cartList[i].id) {
        cartList[i].checked = !cartList[i].checked;
      }
      if (cartList[i].checked) {
        checkedNum++;
      }
    }
    if (checkedNum == cartList.length) {
      checkedAll = true;
    } else {
      checkedAll = false;
    }
    if (checkedNum > 0) {
      delDisable = true;
    } else {
      delDisable = false;
    }
    that.setData({
      cartList: cartList,
      checkedAll: checkedAll,
      delDisabled: delDisable
    })
    that.getSumprice();
  },
  getSumprice: function () {
    var that = this;
    var cartList = that.data.cartList;
    var sumprice = 0;
    for (var i = 0; i < cartList.length; i++) {
      if (cartList[i].checked) {
        sumprice += cartList[i].num * cartList[i].price;
      }
    }
    // console.log(sumprice);
    that.setData({
      sumPrice: sumprice.toFixed(2)
    })
  },
  delCart: function (e) {
    var that = this;
    var type = e.target.dataset.type;
    var id = e.target.dataset.id;
    var cartList = that.data.cartList;
    var delArr = [];
    var delTip = '';
    if (type == 'single') {
      delArr.push(id);
      delTip = "确定要删除这个商品吗？";
    } else if (type == 'multi') {
      delTip = "确定要删除选中的商品吗？";
      for (var i = 0; i < cartList.length; i++) {
        if (cartList[i].checked) {
          delArr.push(cartList[i].id);
        }
      }
    }
    var isEmpty = (delArr.length == that.data.cartList.length);
    delArr = delArr.join(',');
    console.log(delArr);
    if (!that.data.delDisabled && type == 'multi'){
      
    }else{
      wx.showModal({
        title: '',
        content: delTip,
        confirmColor: '#1AAD16',
        success: function (res) {
          if (res.confirm) {
            //发起请求，获取列表列表
            wx.showToast({
              title: '删除中',
              icon: 'loading',
              mask: true,
              duration: 10000
            });
            wx.request({
              url: app.globalData.requestUrl,
              data: {
                map: 'applet_cart_delete',
                // suid: app.globalData.suid,
                ids: delArr
              },
              success: function (res) {
                if (res.data.ec == 200) {
                  console.log(res.data.data);
                  wx.showToast({
                    title: res.data.data.msg,
                    icon: 'success',
                    duration: 2000,
                  })
                  that.onPullDownRefresh();
                  that.getSumprice();
                  console.log(isEmpty);
                  if (isEmpty){
                    that.setData({
                      isEdit: false,
                      checkedAll:false,
                      sumPrice:0
                    })
                  }
                  
                } else {
                  wx.showModal({
                    title: '提示',
                    content: res.data.em,
                    showCancel: false
                  });
                }
              },
              complete: function () {
                wx.hideToast();
              }
            });
            console.log(delArr);
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  onPullDownRefresh: function () {
    this.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    this.onLoad();
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      that.onShow();
    }
  },
  gobuy:function(){
    wx.switchTab({
      url: '../index/index'
    })
  },
  accountOrder:function(){
    var that = this;
    var cartList = that.data.cartList;
    var orderArr = []; 
    var delArr = [];
    var data  = {};
    data.map = 'applet_order_create';
    // data.suid = app.globalData.suid;
    for (var i = 0; i < cartList.length; i++) {
      var cartObj = {};
      if (cartList[i].checked){
        cartObj.gid = cartList[i].gid;
        cartObj.gfid = cartList[i].gfid;;
        cartObj.num = cartList[i].num;
        orderArr.push(cartObj);
        delArr.push(cartList[i].id);
      }
    }
    console.log(JSON.stringify(orderArr));
    if (orderArr.length>0){
      delArr = delArr.join(',');
      wx.setStorage({
        key: "delCart",
        data: delArr
      })
      data.buys = encodeURI(JSON.stringify(orderArr));
      //发起请求，获取列表列表
      wx.showToast({
        title: '加载中',
        icon: 'loading',
        mask: true,
        duration: 10000
      });
      wx.request({
        url: app.globalData.requestUrl,
        data: data,
        success: function (res) {
          if (res.data.ec == 200) {
            console.log(res.data.data);
            wx.setStorage({
              key: "submitOrder",
              data: res.data.data,
              success: function () {
                wx.navigateTo({
                  url: '../waitBuyerPay/waitBuyerPay?ordersource=cartorder'
                })
              }
            })
          } else {
            // wx.showModal({
            //   title: '提示',
            //   content: res.data.em,
            //   showCancel: false
            // });
            app.errorTip(that, res.data.em, 2000);
          }
        },
        complete: function () {
          wx.hideToast();
        }
      });
    }else{
      app.errorTip(that, '请选择要结算的商品', 2000);
    }
  },
  goodDetail: function (e) {
    var that = this;
    var goodId = e.currentTarget.dataset.gid;
    var isEdit = that.data.isEdit;
    console.log(!isEdit);
    if (!isEdit){
      wx.navigateTo({
        url: '../goodDetail/goodDetail?goodid=' + goodId
      })
    }
    
  },
  makeCall: function () {
    app.makeCall();
  }
})