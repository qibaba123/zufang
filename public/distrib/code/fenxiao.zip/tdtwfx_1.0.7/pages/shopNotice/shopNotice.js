var WxParse = require('../../wxParse/wxParse.js');
var app = getApp()
Page({
  data: {
    // showLoading: false,
    // noMoretip: false,
    // page: 0,
    // shopNotice:[]
  },
  onLoad: function () {
    var that = this;
    wx.showLoading({
      title: '加载中'
    })
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map:'applet_shop_new_notice'
      },
      success: function (res) {
        if (res.data.ec == 200) {
         console.log(res.data.data)
         var article = res.data.data.content;
         that.setData({
           noticeContent: res.data.data.content
         })
         WxParse.wxParse('article', 'html', article, that, 5);
        } else {
          console.log(res.data)
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onShow: function () {
    // var that = this;
    // var page = that.data.page;
    //发起请求，获取列表列表
    // wx.showToast({
    //   title: '加载中',
    //   icon: 'loading',
    //   mask: true,
    //   duration: 10000
    // });
    // wx.request({
    //   url: app.globalData.requestUrl,
    //   data: {
    //     map: 'applet_shop_notice',
    //     page: page
    //   },
    //   success: function (res) {
    //     if (res.data.ec == 200) {
    //       console.log(that.data.shopNotice);
    //       var allArr = [];
    //       var initArr = that.data.shopNotice;
    //       var curArr = res.data.data;
    //       var lastPageLength = curArr.length;
    //       if (page > 0) {
    //         allArr = initArr.concat(curArr);
    //       } else {
    //         allArr = res.data.data;
    //       }
    //       that.setData({
    //         shopNotice: allArr
    //       })
    //       console.log(that.data.shopNotice);
    //       if (lastPageLength < 10) {
    //         that.setData({
    //           noMoretip: true,
    //           showLoading: false
    //         });
    //       }
    //     } else {
    //       console.log(res.data)
    //       if (page <= 0) {
    //         that.setData({
    //           shopNotice: []
    //         })
    //       } else {
    //         that.setData({
    //           noMoretip: true,
    //           showLoading: false
    //         });
    //       }
    //     }
    //   },
    //   complete: function () {
    //     wx.hideToast();
    //     wx.stopPullDownRefresh();
    //   }
    // });
  },
//   onPullDownRefresh: function () {
//     this.setData({
//       page: 0,
//       noMoretip: false,
//       showLoading: true
//     });
//     this.onShow();
//     console.log("下拉刷新");
//   },
//   onReachBottom: function () {
//     var that = this;
//     console.log("到达页面底部")
//     var isMore = that.data.noMoretip;
//     var page = that.data.page;
//     page++;
//     that.setData({
//       page: page
//     });
//     if (isMore) {
//       console.log("已完成或正在加载");
//     } else {
//       that.onShow();
//     }
//   }
})