var app = getApp()
Page({
  data: {
    errorTip: {
      text: '',
      isShow: false
    },
    helpList:[]
  },
  onLoad: function () {
    console.log('onLoad');
    var that = this
    that.setData({
      mobile: app.globalData.telphone
    })
  },
  onShow:function(){
    var that = this;
    var data = {};
    app.setNavtitle('帮助中心');

    data.map = 'applet_shop_help';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data);
          that.setData({
            helpList: res.data.data
          })
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
  makeCall: function () {
    app.makeCall();
  },
  openHelpDetail:function(e){
    var content = e.currentTarget.dataset.content;
    console.log(content);
    wx.setStorage({
      key: "helpDetail",
      data: content,
      success:function(){
        wx.navigateTo({
          url: '../helpDetail/helpDetail'
        })
      }
    })
  }
})