//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
  onLoad:function(){
    var that = this;
    
  },
  // 领取优惠券跳转
  getCoupon: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    console.log(id);
    wx.showLoading({
      title: '领取中',
      mask: true
    })
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_coupon_receive',
        cid: id
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          var couponInfo = {
            couponDetail: res.data.data.coupon,
            receiveList: res.data.data.receiveList
          };
          wx.setStorage({
            key: "couponInfo",
            data: couponInfo,
            success: function () {
              wx.navigateTo({
                url: '/pages/useCoupon/useCoupon'
              })
            }
          })

        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideLoading();
      }
    })

  },
})
