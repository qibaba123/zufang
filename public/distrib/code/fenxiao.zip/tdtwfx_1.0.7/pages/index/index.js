//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    slideImgUrls: [],
    goodShow: 2,
    indexTemp: "",
    showType: 'tool',
    shopLogo: "",
    shopGoods: [],
    showLoading: true,
    noMoretip: false,
    page: 0,
    isShowVideo: false
  },
  onLoad: function () {
    var that = this;
    setTimeout(function () {
      that.requestIndex();
      that.requestCoupon();
    }, 1);
  },
  onReady:function(){
    var that = this;
    this.videoContext = wx.createVideoContext('myVideo');
    setTimeout(function () {
      wx.request({
        url: app.globalData.requestUrl,
        data: {
          map: 'applet_promotional_video'
        },
        success: function (res) {
          console.log(res.data);
          if (res.data.ec == 200) {
            that.setData({
              videoInfo: res.data.data,
              showPlaybtn: true
            })
          } else {
            that.setData({
              showPlaybtn: false
            })
          }
        },
        complete: function () {
          wx.hideToast();
          wx.stopPullDownRefresh();
        }
      });
    }, 1)
  },
  onShow: function () {
    var that = this;
    if (app.globalData.plumSession) {
      console.log("已获取到session");
      that.requestPartners();
    } else {
      console.log("暂未获取到session");
      app.wechatSq(that);
      that.onLoad();
    }
    if (!that.data.tempInfo) {
      that.onLoad();
    }
  },
  requestIndex: function () {
    var that = this;
    var page = that.data.page;
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_index_info',
        suid: app.globalData.suid,
        page: page,
        version: app.globalData.version,
        base: app.globalData.base
      },
      success: function (res) {
        console.log(res.data.data);
        if (res.data.ec == 200) {
          that.setData({
            shopLogo: res.data.data.logo,
            shopName: res.data.data.name,
            tempInfo: res.data.data.template,
            slideImgUrls: res.data.data.slide,
            shortMenu: res.data.data.shortcut,
            recommend: res.data.data.recommendGoods,
            kinds: res.data.data.kinds,
            goodShow: res.data.data.template.goodsStyle,
            titleName: res.data.data.template.title,
            shareOpen: res.data.data.shareOpen,
            customerService: res.data.data.customerService
          })
          var sharedata = {
            shareOpen: res.data.data.shareOpen,
            shareUrl: res.data.data.shareUrl,
            shareTitle: res.data.data.template.title
          }
          app.globalData.sharedata = sharedata;
          // 存储是否开启客服
          app.globalData.customerService = res.data.data.customerService;
          // 设置电话
          app.globalData.telphone = res.data.data.mobile;
          app.globalData.watermark = res.data.data.watermark;
          var namelogo = {
            name: res.data.data.name,
            logo: res.data.data.logo
          };
          app.globalData.namelogo = namelogo;
					if (res.data.data.template.title){
						wx.setNavigationBarTitle({
							title: res.data.data.template.title
						});
					}
          var shopname = res.data.data.name;
          var allArr = [];
          var initArr = that.data.shopGoods;
          var curArr = res.data.data.goods;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data.goods;
          }
          that.setData({
            shopGoods: allArr
          })
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          wx.setStorage({
            key: "shopInfoname",
            data: shopname,
            success: function (e) {
              console.log("存储成功")
            }
          })
        } else {
          console.log(res.data)
          if (page <= 0) {
            that.setData({
              shopGoods: []
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  requestPartners: function () {
    var that = this;
    var data = {};
    data.map = 'applet_three_configure';
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            isShowFenxiao: res.data.data.isdistrib,
            isapply: app.globalData.isapply,
            userInfo: app.globalData.userInfo
          })
          app.globalData.isdistrib = res.data.data.isdistrib;
          app.globalData.isapply = res.data.data.isapply;
        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.stopPullDownRefresh();
      }
    });
  },
  onPullDownRefresh: function () {
    this.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    this.onLoad();
    this.onShow();
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    var temp = that.data.tempInfo.temp;
    if (temp == 3 || temp == 4) {
      console.log("到达页面底部")
      var isMore = that.data.noMoretip;
      var page = that.data.page;
      page++;
      that.setData({
        page: page
      });
      if (isMore) {
        console.log("已完成或正在加载");
      } else {
        that.requestIndex();
      }
    }
  },
  hideFenxiaotip:function(){
    var that = this;
    that.setData({
      isShowFenxiao:1
    })
  },
  goodDetail: function (e) {
    var goodId = e.currentTarget.dataset.id;
    if (!goodId){
      return;
    }
    wx.navigateTo({
      url: '../goodDetail/goodDetail?goodid=' + goodId
    })
  },
  changeShowType: function (e) {
    var type = e.target.dataset.type;
    this.setData({
      showType: type
    })
  },
  searchPage: function () {
    wx.navigateTo({
      url: '../searchList/searchList'
    })
  },
  allGoods: function (e) {
    var type = e.currentTarget.dataset.type;
    console.log(type);
    wx.setStorage({
      key: "cuxiao",
      data: type,
      success: function () {
        wx.navigateTo({
          url: '../goodsList/goodsList'
        })
      }
    })
  },
  flGoods: function (e) {
    var id = e.currentTarget.dataset.id;
    console.log(id);
    if (id != "") {
      wx.setStorage({
        key: "flGoodId",
        data: id,
        success: function () {
          wx.navigateTo({
            url: '../flGoodsList/flGoodsList'
          })
        }
      })
    }
  },
  flAllgoods: function (e) {
    var secondid = e.currentTarget.dataset.secondid;
    var title = e.currentTarget.dataset.title;
    console.log(secondid);
    wx.navigateTo({
      url: '/pages/allgoods/allgoods?secondid=' + secondid + '&title=' + title
    })
  },
  shopNotice: function () {
    wx.navigateTo({
      url: '../shopNotice/shopNotice'
    })
  },
  seemap: function (e) {
    var latitude = e.currentTarget.dataset.lat;
    var longitude = e.currentTarget.dataset.lng;
    var address = e.currentTarget.dataset.address;
    var name = e.currentTarget.dataset.name;
    wx.openLocation({
      latitude: Number(latitude),
      longitude: Number(longitude),
      name: name,
      address: address,
      scale: 18
    })
  },
  makeCall: function () {
    app.makeCall();
  },
  playVideo: function () {
    var that = this;
    that.setData({
      isShowVideo: true
    })
    this.videoContext.play();
  },
  hideVideo: function () {
    var that = this;
    that.setData({
      isShowVideo: false
    })
  },
  
  requestCoupon: function () {
    var that = this;
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_coupon_list'
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          that.setData({
            couponList: res.data.data
          })
        } else {
          that.setData({
            couponList: []
          })
        }
      },
      complete: function () {
        wx.hideLoading();
        wx.stopPullDownRefresh();
      }
    })
  },
  // 领取优惠券跳转
  getCoupon: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.id;
    console.log(id);
    wx.showLoading({
      title: '领取中',
      mask: true
    })
    wx.request({
      url: app.globalData.requestUrl,
      data: {
        map: 'applet_coupon_receive',
        cid: id
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.ec == 200) {
          var couponInfo = {
            couponDetail: res.data.data.coupon,
            receiveList: res.data.data.receiveList
          };
          wx.setStorage({
            key: "couponInfo",
            data: couponInfo,
            success: function () {
              wx.navigateTo({
                url: '/pages/useCoupon/useCoupon'
              })
            }
          })

        } else {
          app.errorTip(that, res.data.em, 2000);
        }
      },
      complete: function () {
        wx.hideLoading();
      }
    })

  },
  sharePage: function () {
    wx.navigateTo({
      url: '/pages/sharepage/sharepage'
    })
  },
  toApplyFenxiao: function () {
    wx.navigateTo({
      url: '/pages/becomePartners/becomePartners'
    })
  },
  onShareAppMessage: function () {
    var that = this;
    var title = that.data.titleName;
    console.log(title);
    return {
      title: title,
      path: '/pages/index/index'
    }
  },
})
// 初始化图片高度
function setImageH(that) {
  var goodShow = that.data.goodShow;
  wx.getSystemInfo({
    success: function (res) {
      var imgWidth;
      if (goodShow == 1) {
        imgWidth = res.screenWidth * 0.95
      } else if (goodShow == 2) {
        imgWidth = res.screenWidth * 0.95 * 0.5
      }
      that.setData({
        imageWidth: imgWidth
      })
    }
  })
}