var app = getApp()
Page({
  data: {
		isUnfold:true
  },
  onLoad: function (options) {
  },
  onReady: function () {
  
  },
  onShow: function () {
		
  },
  onShareAppMessage: function () {
  
  }
})