var app = getApp()
Page({
  data: {
  },
  onLoad: function (options) {
		var that = this;
		wx.getStorage({
			key: 'extendInfo',
			success: function(res) {
				that.setData({
					extendInfo: res.data
				})
				console.log(that.data.extendInfo);
			}
		})
  },
	onShow:function(){
	
	},
	toPosterimg:function(){
		var that = this;
		var posterImg = that.data.extendInfo.spreadImage;
		var mid = app.globalData.memberInfo.mid;
		var posterInfo = {
			posterImg: posterImg,
			mid:mid
		}
		app.globalData.posterInfo = posterInfo;
		if (!posterImg){
			app.errorTip(that, "暂未添加海报图片", 2000);
			return;
		}
		wx.navigateTo({
			url: '/pages/posterImg/posterImg'
		})
	},
	requestExtendinfo: function () {
		var that = this;
		var memberInfo = app.globalData.memberInfo;
		console.log(memberInfo);
		var data = {};
		data.map = 'applet_three_share_code';
		data.path = '/pages/extend/extend?mid=' + memberInfo.mid;
		//发起请求，获取列表列表
		wx.showToast({
			title: '加载中',
			icon: 'loading',
			mask: true,
			duration: 10000
		});
		wx.request({
			url: app.globalData.requestUrl,
			data: data,
			success: function (res) {
				console.log(res.data);
				if (res.data.ec == 200) {
					that.setData({
						extendInfo: res.data.data
					})
					console.log(that.data.extendInfo);
				} else {
					app.errorTip(that, res.data.em, 2000);
				}
			},
			complete: function () {
				wx.hideToast();
				wx.stopPullDownRefresh();
			}
		});
	},
	onShareAppMessage:function(){
		var mid = app.globalData.memberInfo.mid;
		return {
			title: '获取分销资格',
      path: '/pages/distributionTip/distributionTip?scene='+mid,
			success: function (res) {
				// 转发成功
				console.log("成功");
			},
			fail: function (res) {
				// 转发失败
				console.log("失败");
			}
		}
	}
})