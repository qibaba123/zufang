
var app = getApp()
Page({
  data: {
    
  },
  onLoad: function (e) {
    console.log('onLoad');
    this.setData({
      orderId: e.orderid
    })
  },
  enterIndex:function(){
    wx.reLaunch({
      url: '../index/index'
    })
  },
  seeOrderDetail:function(){
    var orderId = this.data.orderId;
    wx.redirectTo({
      url: '../orderDetail/orderDetail?orderid=' + orderId
    })
  }
})