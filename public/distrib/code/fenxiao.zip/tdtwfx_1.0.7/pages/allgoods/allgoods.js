//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    sortType: 2,
    showLoading: true,
    noMoretip: false,
    page: 0
  },
  onShow:function(){
    app.setNavtitle('全部商品');
  },
  onLoad: function (e) {
    console.log(e)
    var that = this;
    var oneid = e.oneid;
    var secondid = e.secondid;
    wx.setNavigationBarTitle({
      title: e.title
    })
    that.setData({
      oneid: oneid,
      secondid: secondid
    })
    that.requestAllGoods(oneid, secondid);
  },
  requestAllGoods: function (oneid, secondid){
    var that = this;
    var data = {};
    var page = that.data.page;
    var sortType = that.data.sortType;
    data.map = 'applet_goods_list';
    data.sortType = sortType;
    if(oneid){
      data.kind1 = oneid;
    }
    data.kind2 = secondid;
    data.page = page;
    console.log(data);
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        // console.log(page);
        if (res.data.ec == 200) {
          var allArr = [];
          var initArr = that.data.shopGoods ? that.data.shopGoods:'[]';
          var curArr = res.data.data;
          var lastPageLength = curArr.length;
          if (page > 0) {
            allArr = initArr.concat(curArr);
          } else {
            allArr = res.data.data;
          }
          that.setData({
            shopGoods: allArr
          })
          if (lastPageLength < 10) {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
          console.log(that.data.shopGoods);
        } else {
          console.log(res.data)
          if (page <= 0) {
            that.setData({
              shopGoods: []
            })
          } else {
            that.setData({
              noMoretip: true,
              showLoading: false
            });
          }
        }
      },
      complete: function () {
        wx.hideToast();
        wx.stopPullDownRefresh();
      }
    });
  },
  onPullDownRefresh: function () {
    var that = this;
    var oneid = that.data.oneid;
    var secondid = that.data.secondid;
    that.setData({
      page: 0,
      noMoretip: false,
      showLoading: true
    });
    that.requestAllGoods(oneid, secondid);
    console.log("下拉刷新");
  },
  onReachBottom: function () {
    var that = this;
    var oneid = that.data.oneid;
    var secondid = that.data.secondid;
    console.log("到达页面底部")
    var isMore = that.data.noMoretip;
    var page = that.data.page;
    page++;
    that.setData({
      page: page
    });
    if (isMore) {
      console.log("已完成或正在加载");
    } else {
      that.requestAllGoods(oneid, secondid);
    }
  },
  goodDetail: function (e) {
    var goodId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../goodDetail/goodDetail?goodid=' + goodId
    })
  },
  changeShowType: function (e) {
    var type = e.target.dataset.type;
    this.setData({
      showType: type
    })
  },
  searchPage: function () {
    wx.navigateTo({
      url: '../searchList/searchList'
    })
  },
  sortGood: function (e) {
    var type = e.target.dataset.sort;
    this.setData({
      sortType: type
    })
    this.onPullDownRefresh();
  }
})