//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
  },
  onLoad:function(){
    var that = this;
    that.setData({
      namelogo: app.globalData.namelogo
    })
    that.requestCode();
  },
  onShow:function(){
    var that = this;
  },
  requestCode: function (e) {
    var that = this;
    var data = {};
    data.map = 'applet_receivables_code';
    //发起请求，获取列表列表
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      mask: true,
      duration: 10000
    });
    wx.request({
      url: app.globalData.requestUrl,
      data: data,
      success: function (res) {
        if (res.data.ec == 200) {
          console.log(res.data.data);
          that.setData({
            codeImg:res.data.data.code
          })
          
        } else {
          wx.showModal({
            title: '提示',
            content: res.data.em,
            showCancel: false
          });
        }
      },
      complete: function () {
        wx.hideToast();
      }
    });
  },
})
