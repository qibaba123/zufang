//app.js
var rqcfg = require('./utils/constant.js');
App({
  data:{
    
  },
  onLaunch: function () {
    var that = this;
    if (rqcfg.rqcfg.suid) {
      that.globalData.requestUrl = rqcfg.rqcfg.rqurl + 'suid=' + rqcfg.rqcfg.suid;
      that.globalData.version = rqcfg.rqcfg.version;
    } else {
      if (wx.getExtConfig) {
        wx.getExtConfig({
          success: function (res) {
            console.log(res.extConfig)
            that.globalData.menuTitle = res.extConfig.menu;
            var suid = res.extConfig.suid;
            var version = res.extConfig.version;
            var base = res.extConfig.base;
            rqcfg.rqcfg.rqurl = rqcfg.rqcfg.rqurl + 'suid=' + suid;
            that.globalData.requestUrl = rqcfg.rqcfg.rqurl;
            console.log(that.globalData.requestUrl)
            that.globalData.suid = suid;
            that.globalData.version = version;
            that.globalData.base = base;
            // 微信授权获取信息
            that.wechatSq();
          }
        })
      }
    }
    
  },
  globalData: {
    userInfo: null,
    plumSession: null,
    suid: rqcfg.rqcfg.suid,
    requestUrl: rqcfg.rqcfg.rqurl,
    domin:rqcfg.rqcfg.domin
  },
  errorTip: function (that, text, timer){
    that.setData({
      errorTip: {
        text: text,
        isShow: true
      }
    })
    setTimeout(function () {
      that.setData({
        errorTip: {
          text: '',
          isShow: false
        }
      })
    }, timer)
  },
  wechatSq:function(obj){
    var that = this;
    wx.login({
      success: function (res) {
        var code = res.code;
        console.log(code);
        if (res.code) {
          wx.getUserInfo({
            success: function (res2) {
              var encryptedData = encodeURI(res2.encryptedData);
              var iv = encodeURI(res2.iv);
              // var userInfo = res2.userInfo;
              // var nickName = userInfo.nickName;
              // var avatarUrl = userInfo.avatarUrl;
              // var gender = userInfo.gender; //性别 0：未知、1：男、2：女
              // var province = userInfo.province;
              // var city = userInfo.city;
              // var country = userInfo.country;
              var data = {
                map: 'applet_three_member_info',
                suid: rqcfg.rqcfg.suid,
                code: code,
                encryptedData: encryptedData,
                iv: iv
              };
							console.log(data);
              console.log('code=' + code + '&encryptedData=' + encryptedData + '&iv=' + iv);
              wx.request({
                url: that.globalData.requestUrl,
                data: data,
                success: function (res) {
                  if (res.data.ec == 200) {
                    console.log("获取用户信息成功");
                    console.log(res.data.data);
                    that.globalData.isdistrib = res.data.data.isdistrib;
                    that.globalData.isapply = res.data.data.isapply;
                    that.globalData.requestUrl = that.globalData.requestUrl + '&plum_session_applet=' + res.data.data.plum_session_applet;
                    wx.setStorage({
                      key: "plumSession",
                      data: res.data.data.plum_session_applet,
                      success:function(){
                        that.globalData.plumSession = res.data.data.plum_session_applet;
                      }
                    })
                    if(obj){
                      obj.setData({
                        userInfo: res.data.data,
                        isShowFenxiao: res.data.data.isdistrib,
                        isapply: res.data.data.isapply
                      })
                      console.log("------------");
                    }
                    if (that.globalData.userInfo) {
                      typeof cb == "function" && cb(this.globalData.userInfo)
                    } else{
                      that.globalData.userInfo = res.data.data
                      typeof cb == "function" && cb(that.globalData.userInfo)
                    }
                  } else {
                    console.log(res.data);
                    console.log("获取用户信息失败");
										wx.showToast({
											title: '获取用户信息失败',
											icon: 'success',
											image:'/images/error_tip.png',
											duration: 3000
										})
                  }
                },
                complete: function () {
                  console.log("执行完成");
                }
              });
            },
            fail:function(){
              wx.showModal({
                title: '警告',
                content: '您拒绝了授权，将无法正常使用该小程序的功能体验。请允许授权哦~。',
                showCancel: false,
                confirmText: '去授权',
                success: function (res) {
                  if (res.confirm) {
                    that.openSetting();
                  }
                }
              })
            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    });
  },
  makeCall: function () {
    var mobile = this.globalData.telphone;
    console.log(mobile);
    wx.showModal({
      title: '',
      content: mobile,
      confirmText: '拨打',
      confirmColor: '#48C23D',
      success: function (res) {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: mobile,
            success: function () {
              console.log("拨打电话成功！")
            },
            fail: function () {
              console.log("拨打电话失败！")

            }
          })
        }
      }
    })
  },
  makeCallphone: function (mobile) {
    console.log(mobile);
    wx.showModal({
      title: '',
      content: mobile,
      confirmText: '拨打',
      confirmColor: '#48C23D',
      success: function (res) {
        if (res.confirm) {
          wx.makePhoneCall({
            phoneNumber: mobile,
            success: function () {
              console.log("拨打电话成功！")
            },
            fail: function () {
              console.log("拨打电话失败！")

            }
          })
        }
      }
    })
  },
  setVersion: function (obj) {
    var that = this;
    obj.setData({
      curVersion: that.globalData.version,
      watermark: that.globalData.watermark
    })
  },
  //跳转设置页面授权
  openSetting: function () {
    var that = this;
    if (wx.openSetting) {
      wx.openSetting({
        success: function (res) {
          res.authSetting = {
            "scope.userInfo": true,
            "scope.userLocation": true,
            "scope.address": true
          }
          // that.wechatSq();
          // //尝试再次登录
          wx.reLaunch({
            url: '/pages/index/index',
          })
        }
      })
    } else {
      wx.showModal({
        title: '授权提示',
        content: '小程序需要您的微信授权才能使用哦~ 错过授权页面的处理方法：1、请10分钟后再次点击授权。 2、删除小程序->重新搜索进入->点击授权按钮。'
      })
    }
  },
  //设置导航条字样
  setNavtitle: function (name) {
    var that = this;
    var path = getCurrentPages()[getCurrentPages().length - 1].__route__;
    var menu = that.globalData.menuTitle;
    var title = name;
    if (!menu) {
      title = name;
    } else {
      if (!menu[path]) {
        title = name;
      } else {
        title = menu[path];
      }
    }
    console.log(title);
    wx.setNavigationBarTitle({
      title: title
    })
  },
})

