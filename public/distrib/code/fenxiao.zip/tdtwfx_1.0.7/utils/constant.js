var rqcfg = {
	domin: '',
  	rqurl: '',
	suid: '',
  version: '1.0.7'
};
module.exports = {
  rqcfg: rqcfg
}
